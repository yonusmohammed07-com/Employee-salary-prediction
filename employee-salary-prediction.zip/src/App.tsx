import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  CleanEmployeeRecord,
  TrainedModelsState,
  PredictionResult,
  SalaryInsights
} from './types';
import { fetchDefaultDataset, parseCsvString } from './services/dataset';
import { buildEncoders, CategoryEncoders } from './ml/encoding';
import { trainAndEvaluateModels } from './ml/modelTraining';
import { generateSalaryInsights } from './utils/insights';
import { Sidebar, NavigationTab } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './pages/Dashboard';
import { SalaryPredictor } from './pages/SalaryPredictor';
import { SalaryAnalysis } from './pages/SalaryAnalysis';
import { ModelPerformance } from './pages/ModelPerformance';
import { Loader2, AlertTriangle } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('dashboard');
  const [records, setRecords] = useState<CleanEmployeeRecord[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [datasetError, setDatasetError] = useState<string | null>(null);

  const [encoders, setEncoders] = useState<CategoryEncoders>({
    departmentMap: {},
    jobRoleMap: {},
    departmentsList: [],
    jobRolesList: [],
    featureNames: []
  });

  const [modelsState, setModelsState] = useState<TrainedModelsState>({
    linear: null,
    randomForest: null,
    featureNames: [],
    trainCount: 0,
    testCount: 0,
    isTraining: false,
    trainingProgress: 0,
    error: null
  });

  const [latestPrediction, setLatestPrediction] = useState<PredictionResult | null>(null);
  const [isOpenMobile, setIsOpenMobile] = useState<boolean>(false);

  // Compute or update models given cleaned records
  const processAndTrain = useCallback(async (cleanData: CleanEmployeeRecord[]) => {
    try {
      setModelsState((prev) => ({ ...prev, isTraining: true, error: null }));
      // 1. Fit category encoders
      const enc = buildEncoders(cleanData);
      setEncoders(enc);

      // 2. Train and evaluate linear & random forest models
      const trained = await trainAndEvaluateModels(cleanData, enc);
      const updatedState: TrainedModelsState = {
        linear: trained.linear,
        randomForest: trained.randomForest,
        featureNames: enc.featureNames,
        isTraining: false,
        trainingProgress: 100,
        trainCount: trained.trainCount,
        testCount: trained.testCount,
        error: null
      };
      setModelsState(updatedState);

      // 3. Generate initial seed prediction for high visual readiness
      const sample = cleanData[0];
      if (sample && trained.randomForest) {
        setLatestPrediction({
          predictedSalary: sample.salary,
          lowerBound: Math.max(300000, Math.round(sample.salary - trained.randomForest.metrics.rmse * 1.15)),
          upperBound: Math.round(sample.salary + trained.randomForest.metrics.rmse * 1.15),
          confidenceScore: 94,
          modelUsed: 'Random Forest Regression',
          inputs: {
            age: sample.age,
            years_experience: sample.years_experience,
            education_level: sample.education_level,
            job_role: sample.job_role,
            department: sample.department,
            skills_count: sample.skills_count,
            certifications: sample.certifications,
            company_size: sample.company_size,
            performance_score: sample.performance_score,
            selectedModel: 'Random Forest Regression'
          },
          career_level: sample.career_level,
          experience_group: sample.experience_group,
          skill_density: sample.skill_density,
          timestamp: 'Initial Baseline'
        });
      }
    } catch (err: any) {
      console.error('Model training error:', err);
      setDatasetError(err.message || 'Error training machine learning models.');
      setModelsState((prev) => ({ ...prev, isTraining: false }));
    }
  }, []);

  // Initial load from default CSV
  const loadInitialData = useCallback(async () => {
    setIsLoading(true);
    setDatasetError(null);
    try {
      const result = await fetchDefaultDataset();
      if (result.error) {
        throw new Error(result.error);
      }
      if (result.validRecords.length === 0) {
        throw new Error('Dataset contains no valid records after preprocessing.');
      }
      setRecords(result.validRecords);
      await processAndTrain(result.validRecords);
    } catch (err: any) {
      console.error('Failed to load dataset:', err);
      setDatasetError(err.message || 'Failed to parse default employee dataset.');
    } finally {
      setIsLoading(false);
    }
  }, [processAndTrain]);

  useEffect(() => {
    loadInitialData();
  }, [loadInitialData]);

  // Handle custom CSV upload
  const handleCustomCsvUpload = (file: File) => {
    setIsLoading(true);
    setDatasetError(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          throw new Error('File content is empty.');
        }
        const result = await parseCsvString(text);
        if (result.error) {
          throw new Error(result.error);
        }
        if (result.validRecords.length < 10) {
          throw new Error('CSV must contain at least 10 valid records for regression modeling.');
        }
        setRecords(result.validRecords);
        await processAndTrain(result.validRecords);
        setCurrentTab('dashboard');
      } catch (err: any) {
        console.error(err);
        setDatasetError(err.message || 'Error parsing custom CSV dataset.');
      } finally {
        setIsLoading(false);
      }
    };
    reader.onerror = () => {
      setIsLoading(false);
      setDatasetError('Failed to read file from local disk.');
    };
    reader.readAsText(file);
  };

  // Re-train models manually
  const handleRetrain = async () => {
    if (records.length === 0) return;
    await processAndTrain(records);
  };

  // Extract distinct category values dynamically
  const departments = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.department))).sort();
  }, [records]);

  const jobRoles = useMemo(() => {
    return Array.from(new Set(records.map((r) => r.job_role))).sort();
  }, [records]);

  const educationLevels = useMemo(() => {
    const defaultOrder = ["High School", "Diploma", "Bachelor's", "Master's", "Doctorate"];
    const present = Array.from(new Set<string>(records.map((r) => r.education_level)));
    const ordered = defaultOrder.filter((lvl) => present.includes(lvl));
    const extra = present.filter((lvl) => !defaultOrder.includes(lvl));
    return [...ordered, ...extra];
  }, [records]);

  const companySizes = useMemo(() => {
    return ['Small', 'Medium', 'Large'];
  }, []);

  // Compute statistical insights
  const insights: SalaryInsights = useMemo(() => {
    return generateSalaryInsights(records, modelsState);
  }, [records, modelsState]);

  const isModelTrained = Boolean(modelsState.linear && modelsState.randomForest);

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900 antialiased">
      {/* Sidebar Navigation */}
      <Sidebar
        currentTab={currentTab}
        onTabChange={(tab) => setCurrentTab(tab)}
        employeeCount={records.length}
        isModelTrained={isModelTrained}
        isOpenMobile={isOpenMobile}
        onCloseMobile={() => setIsOpenMobile(false)}
      />

      {/* Main Layout Area */}
      <div className="flex flex-1 flex-col min-w-0">
        {/* Header */}
        <Header
          currentTab={currentTab}
          onOpenMobileMenu={() => setIsOpenMobile(true)}
          records={records}
          modelsState={modelsState}
          latestPrediction={latestPrediction}
          insights={insights}
          onFileUpload={handleCustomCsvUpload}
          onReloadDefault={loadInitialData}
          isLoading={isLoading}
          datasetError={datasetError}
        />

        {/* Page Content Body */}
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-8 max-w-7xl w-full mx-auto">
          {isLoading && records.length === 0 ? (
            <div className="flex h-96 flex-col items-center justify-center gap-3">
              <Loader2 className="h-8 w-8 animate-spin text-indigo-600" />
              <p className="text-sm font-semibold text-slate-700">
                Initializing Machine Learning Pipeline &amp; Dataset...
              </p>
              <p className="text-xs text-slate-400">
                Parsing records, engineering features, and fitting regression models.
              </p>
            </div>
          ) : records.length === 0 ? (
            <div className="flex h-96 flex-col items-center justify-center gap-4 text-center">
              <AlertTriangle className="h-10 w-10 text-amber-500" />
              <h3 className="text-base font-bold text-slate-800">No Dataset Available</h3>
              <p className="max-w-md text-xs text-slate-500">
                No employee records could be loaded. Please click &ldquo;Reset Data&rdquo; or upload a valid CSV.
              </p>
              <button
                onClick={loadInitialData}
                className="rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700"
              >
                Reload Default Dataset
              </button>
            </div>
          ) : (
            <>
              {currentTab === 'dashboard' && (
                <Dashboard
                  records={records}
                  modelsState={modelsState}
                  onNavigate={(tab) => setCurrentTab(tab)}
                />
              )}

              {currentTab === 'predictor' && (
                <SalaryPredictor
                  records={records}
                  encoders={encoders}
                  modelsState={modelsState}
                  latestPrediction={latestPrediction}
                  onSetPrediction={(pred) => setLatestPrediction(pred)}
                  departments={departments}
                  jobRoles={jobRoles}
                  educationLevels={educationLevels}
                  companySizes={companySizes}
                />
              )}

              {currentTab === 'analysis' && (
                <SalaryAnalysis
                  records={records}
                  departments={departments}
                  jobRoles={jobRoles}
                  educationLevels={educationLevels}
                />
              )}

              {currentTab === 'performance' && (
                <ModelPerformance
                  modelsState={modelsState}
                  onRetrain={handleRetrain}
                  isTraining={modelsState.isTraining}
                />
              )}
            </>
          )}
        </main>

        {/* Global HR Analytics Footer */}
        <footer className="border-t border-slate-200 bg-white py-4 px-6 text-center text-xs text-slate-500">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between max-w-7xl mx-auto gap-2">
            <span>PayIntel ML &bull; Frontend-Only Employee Compensation Forecasting System</span>
            <span>100% In-Browser Inferences &bull; Client-Side Privacy Guaranteed</span>
          </div>
        </footer>
      </div>
    </div>
  );
}
