import React, { ReactNode } from 'react';

interface ChartCardProps {
  id?: string;
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  id,
  title,
  subtitle,
  action,
  children,
  className = ''
}) => {
  return (
    <div
      id={id}
      className={`flex flex-col rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-all ${className}`}
    >
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 mb-4">
        <div>
          <h3 className="text-base font-semibold text-slate-900">{title}</h3>
          {subtitle && <p className="text-xs text-slate-500">{subtitle}</p>}
        </div>
        {action && <div className="mt-2 sm:mt-0">{action}</div>}
      </div>
      <div className="min-w-0 flex-1 w-full">{children}</div>
    </div>
  );
};
