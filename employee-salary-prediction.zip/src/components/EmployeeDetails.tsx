import React from 'react';
import { X, User, Briefcase, Award, TrendingUp, DollarSign } from 'lucide-react';
import { CleanEmployeeRecord } from '../types';
import { formatCurrency } from '../utils/salaryAnalysis';

interface EmployeeDetailsProps {
  employee: CleanEmployeeRecord | null;
  departmentAverage: number;
  onClose: () => void;
}

export const EmployeeDetails: React.FC<EmployeeDetailsProps> = ({
  employee,
  departmentAverage,
  onClose
}) => {
  if (!employee) return null;

  const diffFromDeptAvg = employee.salary - departmentAverage;
  const diffPct = departmentAverage > 0 ? Math.round((diffFromDeptAvg / departmentAverage) * 100) : 0;

  return (
    <div
      id="employee-details-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-white font-bold text-sm">
              <User className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Employee {employee.employee_id}
              </h3>
              <p className="text-xs text-slate-500">
                {employee.job_role} &bull; {employee.department}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-200 hover:text-slate-600 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="max-h-[75vh] overflow-y-auto p-6 space-y-6">
          {/* Salary Highlight */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between rounded-xl bg-slate-900 p-5 text-white">
            <div>
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">
                Current Annual Compensation
              </span>
              <div className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-white">
                {formatCurrency(employee.salary)}
              </div>
            </div>
            <div className="mt-3 sm:mt-0 text-left sm:text-right">
              <span className="text-xs text-slate-400">Comparison to Dept Avg</span>
              <div
                className={`mt-1 text-sm font-semibold inline-flex items-center gap-1 rounded-full px-2.5 py-1 ${
                  diffFromDeptAvg >= 0 ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}
              >
                <TrendingUp className="h-3.5 w-3.5" />
                {diffFromDeptAvg >= 0 ? `+${diffPct}%` : `${diffPct}%`} ({formatCurrency(Math.abs(diffFromDeptAvg))})
              </div>
            </div>
          </div>

          {/* Profile Details Grid */}
          <div>
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              Employee Professional Attributes
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Age</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.age} years</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Gender</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.gender}</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Education</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.education_level}</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Experience</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.years_experience} years</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Company Size</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.company_size}</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Performance Score</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.performance_score}/100</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Skills Count</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.skills_count} verified</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Certifications</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.certifications} credentials</p>
              </div>
              <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
                <span className="text-xs text-slate-500">Department</span>
                <p className="text-sm font-semibold text-slate-900 mt-0.5">{employee.department}</p>
              </div>
            </div>
          </div>

          {/* Derived Features Calculation */}
          <div>
            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">
              Engineered Machine Learning Features
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="rounded-lg border border-indigo-100 bg-indigo-50/50 p-3.5">
                <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-medium">
                  <Briefcase className="h-4 w-4" />
                  <span>Career Level</span>
                </div>
                <p className="mt-1 text-base font-bold text-slate-900">{employee.career_level}</p>
                <span className="text-[11px] text-slate-500">Derived from {employee.years_experience}y tenure</span>
              </div>

              <div className="rounded-lg border border-indigo-100 bg-indigo-50/50 p-3.5">
                <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-medium">
                  <Award className="h-4 w-4" />
                  <span>Experience Group</span>
                </div>
                <p className="mt-1 text-base font-bold text-slate-900">{employee.experience_group}</p>
                <span className="text-[11px] text-slate-500">Standardized cohort</span>
              </div>

              <div className="rounded-lg border border-indigo-100 bg-indigo-50/50 p-3.5">
                <div className="flex items-center gap-1.5 text-xs text-indigo-700 font-medium">
                  <TrendingUp className="h-4 w-4" />
                  <span>Skill Density</span>
                </div>
                <p className="mt-1 text-base font-bold text-slate-900">{employee.skill_density}</p>
                <span className="text-[11px] text-slate-500">Skills per year ratio</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end border-t border-slate-100 bg-slate-50 px-6 py-3.5">
          <button
            onClick={onClose}
            className="rounded-lg bg-white border border-slate-300 px-4 py-2 text-xs font-medium text-slate-700 shadow-xs hover:bg-slate-50"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
