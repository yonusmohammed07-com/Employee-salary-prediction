import React, { useState } from 'react';
import { Sparkles, AlertCircle } from 'lucide-react';
import { PredictionInput } from '../types';

interface EmployeeFormProps {
  departments: string[];
  jobRoles: string[];
  educationLevels: string[];
  companySizes: string[];
  onSubmit: (input: PredictionInput) => void;
  isModelReady: boolean;
}

export const EmployeeForm: React.FC<EmployeeFormProps> = ({
  departments,
  jobRoles,
  educationLevels,
  companySizes,
  onSubmit,
  isModelReady
}) => {
  const [age, setAge] = useState<number>(29);
  const [yearsExp, setYearsExp] = useState<number>(5);
  const [education, setEducation] = useState<string>("Bachelor's");
  const [jobRole, setJobRole] = useState<string>(jobRoles[0] || 'Software Engineer');
  const [department, setDepartment] = useState<string>(departments[0] || 'Engineering');
  const [skillsCount, setSkillsCount] = useState<number>(6);
  const [certifications, setCertifications] = useState<number>(2);
  const [companySize, setCompanySize] = useState<string>('Medium');
  const [performanceScore, setPerformanceScore] = useState<number>(85);
  const [selectedModel, setSelectedModel] = useState<
    'Linear Regression' | 'Random Forest Regression'
  >('Random Forest Regression');

  const [validationError, setValidationError] = useState<string | null>(null);

  // Update default selections if props load asynchronously
  React.useEffect(() => {
    if (departments.length > 0 && !departments.includes(department)) {
      setDepartment(departments[0]);
    }
  }, [departments]);

  React.useEffect(() => {
    if (jobRoles.length > 0 && !jobRoles.includes(jobRole)) {
      setJobRole(jobRoles[0]);
    }
  }, [jobRoles]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // Range & sanity validations
    if (age < 18 || age > 100) {
      setValidationError('Age must be between 18 and 100.');
      return;
    }

    if (yearsExp < 0 || yearsExp > 60) {
      setValidationError('Years of experience must be between 0 and 60.');
      return;
    }

    if (yearsExp > age - 16) {
      setValidationError(`Years of experience (${yearsExp}) cannot exceed age (${age}) minus minimum working age (16).`);
      return;
    }

    if (skillsCount < 0) {
      setValidationError('Skills count cannot be negative.');
      return;
    }

    if (certifications < 0) {
      setValidationError('Certifications count cannot be negative.');
      return;
    }

    if (performanceScore < 0 || performanceScore > 100) {
      setValidationError('Performance score must be between 0 and 100.');
      return;
    }

    onSubmit({
      age: Number(age),
      years_experience: Number(yearsExp),
      education_level: education,
      job_role: jobRole,
      department,
      skills_count: Number(skillsCount),
      certifications: Number(certifications),
      company_size: companySize,
      performance_score: Number(performanceScore),
      selectedModel
    });
  };

  return (
    <form
      id="salary-prediction-form"
      onSubmit={handleSubmit}
      className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs"
    >
      <div className="flex flex-col gap-1 border-b border-slate-100 pb-4 mb-6">
        <h3 className="text-lg font-bold text-slate-900">Employee Profile Information</h3>
        <p className="text-xs text-slate-500">
          Specify candidate or employee credentials to run real-time browser inference.
        </p>
      </div>

      {validationError && (
        <div className="mb-5 flex items-center gap-2 rounded-lg bg-rose-50 p-3 text-xs font-medium text-rose-800 border border-rose-200">
          <AlertCircle className="h-4 w-4 shrink-0 text-rose-600" />
          <span>{validationError}</span>
        </div>
      )}

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {/* Age */}
        <div>
          <label htmlFor="input-age" className="block text-xs font-semibold text-slate-700">
            Age (years)
          </label>
          <input
            id="input-age"
            type="number"
            min={18}
            max={100}
            required
            value={age}
            onChange={(e) => setAge(Number(e.target.value))}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Years of Experience */}
        <div>
          <label htmlFor="input-experience" className="block text-xs font-semibold text-slate-700">
            Years of Experience
          </label>
          <input
            id="input-experience"
            type="number"
            min={0}
            max={60}
            step={1}
            required
            value={yearsExp}
            onChange={(e) => setYearsExp(Number(e.target.value))}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Education Level */}
        <div>
          <label htmlFor="select-education" className="block text-xs font-semibold text-slate-700">
            Education Level
          </label>
          <select
            id="select-education"
            value={education}
            onChange={(e) => setEducation(e.target.value)}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          >
            {educationLevels.map((lvl) => (
              <option key={lvl} value={lvl}>
                {lvl}
              </option>
            ))}
          </select>
        </div>

        {/* Department */}
        <div>
          <label htmlFor="select-department" className="block text-xs font-semibold text-slate-700">
            Department
          </label>
          <select
            id="select-department"
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          >
            {departments.map((dept) => (
              <option key={dept} value={dept}>
                {dept}
              </option>
            ))}
          </select>
        </div>

        {/* Job Role */}
        <div>
          <label htmlFor="select-job-role" className="block text-xs font-semibold text-slate-700">
            Job Role
          </label>
          <select
            id="select-job-role"
            value={jobRole}
            onChange={(e) => setJobRole(e.target.value)}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          >
            {jobRoles.map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}
          </select>
        </div>

        {/* Company Size */}
        <div>
          <label htmlFor="select-company-size" className="block text-xs font-semibold text-slate-700">
            Company Size
          </label>
          <select
            id="select-company-size"
            value={companySize}
            onChange={(e) => setCompanySize(e.target.value)}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          >
            {companySizes.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </div>

        {/* Skills Count */}
        <div>
          <label htmlFor="input-skills-count" className="block text-xs font-semibold text-slate-700">
            Skills Count (Proficiencies)
          </label>
          <input
            id="input-skills-count"
            type="number"
            min={0}
            max={30}
            required
            value={skillsCount}
            onChange={(e) => setSkillsCount(Number(e.target.value))}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Certifications */}
        <div>
          <label htmlFor="input-certifications" className="block text-xs font-semibold text-slate-700">
            Certifications Count
          </label>
          <input
            id="input-certifications"
            type="number"
            min={0}
            max={20}
            required
            value={certifications}
            onChange={(e) => setCertifications(Number(e.target.value))}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Performance Score */}
        <div>
          <label htmlFor="input-performance" className="block text-xs font-semibold text-slate-700">
            Performance Score (0 – 100)
          </label>
          <input
            id="input-performance"
            type="number"
            min={0}
            max={100}
            required
            value={performanceScore}
            onChange={(e) => setPerformanceScore(Number(e.target.value))}
            className="mt-1.5 block w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Model Selection Toggle */}
      <div className="mt-6 pt-5 border-t border-slate-100">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <span className="block text-xs font-semibold text-slate-700">
              Inference Regression Model
            </span>
            <span className="text-xs text-slate-500">
              Select which trained regression model executes prediction
            </span>
          </div>
          <div className="inline-flex rounded-lg border border-slate-200 bg-slate-50 p-1">
            <button
              type="button"
              id="model-select-rf"
              onClick={() => setSelectedModel('Random Forest Regression')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                selectedModel === 'Random Forest Regression'
                  ? 'bg-white text-indigo-600 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Random Forest
            </button>
            <button
              type="button"
              id="model-select-lr"
              onClick={() => setSelectedModel('Linear Regression')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                selectedModel === 'Linear Regression'
                  ? 'bg-white text-indigo-600 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Linear Regression
            </button>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="mt-6 flex items-center justify-end">
        <button
          type="submit"
          id="btn-predict-salary"
          disabled={!isModelReady}
          className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-6 py-2.5 text-sm font-semibold text-white shadow-xs hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <Sparkles className="h-4 w-4" />
          <span>Predict Salary</span>
        </button>
      </div>
    </form>
  );
};
