import React, { useState, useMemo } from 'react';
import {
  Search,
  ChevronDown,
  ChevronUp,
  ChevronsUpDown,
  ChevronLeft,
  ChevronRight,
  Filter,
  Eye
} from 'lucide-react';
import { CleanEmployeeRecord } from '../types';
import { formatCurrency } from '../utils/salaryAnalysis';
import { EmployeeDetails } from './EmployeeDetails';

interface EmployeeTableProps {
  records: CleanEmployeeRecord[];
  departments: string[];
  jobRoles: string[];
  educationLevels: string[];
}

type SortField =
  | 'employee_id'
  | 'years_experience'
  | 'education_level'
  | 'job_role'
  | 'department'
  | 'skills_count'
  | 'certifications'
  | 'performance_score'
  | 'salary';

export const EmployeeTable: React.FC<EmployeeTableProps> = ({
  records,
  departments,
  jobRoles,
  educationLevels
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [eduFilter, setEduFilter] = useState('ALL');

  const [sortField, setSortField] = useState<SortField>('salary');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  const [selectedEmployee, setSelectedEmployee] = useState<CleanEmployeeRecord | null>(null);

  // Filter and sort records
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        searchTerm === '' ||
        r.employee_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.job_role.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.department.toLowerCase().includes(searchTerm.toLowerCase());

      const matchDept = deptFilter === 'ALL' || r.department === deptFilter;
      const matchRole = roleFilter === 'ALL' || r.job_role === roleFilter;
      const matchEdu = eduFilter === 'ALL' || r.education_level === eduFilter;

      return matchSearch && matchDept && matchRole && matchEdu;
    });
  }, [records, searchTerm, deptFilter, roleFilter, eduFilter]);

  const sortedRecords = useMemo(() => {
    return [...filteredRecords].sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      if (typeof valA === 'string') {
        valA = (valA as string).toLowerCase();
        valB = (valB as string).toLowerCase();
      }

      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredRecords, sortField, sortOrder]);

  const totalPages = Math.max(1, Math.ceil(sortedRecords.length / pageSize));
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedRecords.slice(start, start + pageSize);
  }, [sortedRecords, currentPage, pageSize]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) {
      return <ChevronsUpDown className="h-3.5 w-3.5 text-slate-400" />;
    }
    return sortOrder === 'asc' ? (
      <ChevronUp className="h-3.5 w-3.5 text-indigo-600" />
    ) : (
      <ChevronDown className="h-3.5 w-3.5 text-indigo-600" />
    );
  };

  // Calculate department average for details modal
  const departmentAvg = useMemo(() => {
    if (!selectedEmployee) return 0;
    const sameDept = records.filter((r) => r.department === selectedEmployee.department);
    if (sameDept.length === 0) return 0;
    return Math.round(sameDept.reduce((acc, r) => acc + r.salary, 0) / sameDept.length);
  }, [selectedEmployee, records]);

  return (
    <div className="rounded-xl border border-slate-200 bg-white shadow-xs">
      {/* Table Controls */}
      <div className="border-b border-slate-100 p-4 sm:p-5">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          {/* Search bar */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              id="input-employee-search"
              type="text"
              placeholder="Search by Employee ID, role, or department..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full rounded-lg border border-slate-300 pl-9 pr-3 py-2 text-xs text-slate-900 shadow-xs focus:border-indigo-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Department Filter */}
            <select
              id="filter-dept"
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs text-slate-700 shadow-xs focus:border-indigo-500 focus:outline-hidden"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>

            {/* Role Filter */}
            <select
              id="filter-role"
              value={roleFilter}
              onChange={(e) => {
                setRoleFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs text-slate-700 shadow-xs focus:border-indigo-500 focus:outline-hidden"
            >
              <option value="ALL">All Roles</option>
              {jobRoles.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>

            {/* Education Filter */}
            <select
              id="filter-edu"
              value={eduFilter}
              onChange={(e) => {
                setEduFilter(e.target.value);
                setCurrentPage(1);
              }}
              className="rounded-lg border border-slate-300 bg-white px-2.5 py-2 text-xs text-slate-700 shadow-xs focus:border-indigo-500 focus:outline-hidden"
            >
              <option value="ALL">All Education</option>
              {educationLevels.map((e) => (
                <option key={e} value={e}>
                  {e}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Data Table */}
      <div className="overflow-x-auto min-w-0">
        <table className="w-full text-left text-xs text-slate-600">
          <thead className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-700 uppercase tracking-wider">
            <tr>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('employee_id')}
              >
                <div className="flex items-center gap-1">
                  <span>Employee ID</span>
                  {getSortIcon('employee_id')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('years_experience')}
              >
                <div className="flex items-center gap-1">
                  <span>Experience</span>
                  {getSortIcon('years_experience')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('education_level')}
              >
                <div className="flex items-center gap-1">
                  <span>Education</span>
                  {getSortIcon('education_level')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('job_role')}
              >
                <div className="flex items-center gap-1">
                  <span>Job Role</span>
                  {getSortIcon('job_role')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('department')}
              >
                <div className="flex items-center gap-1">
                  <span>Department</span>
                  {getSortIcon('department')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('skills_count')}
              >
                <div className="flex items-center gap-1">
                  <span>Skills</span>
                  {getSortIcon('skills_count')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('certifications')}
              >
                <div className="flex items-center gap-1">
                  <span>Certs</span>
                  {getSortIcon('certifications')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100"
                onClick={() => handleSort('performance_score')}
              >
                <div className="flex items-center gap-1">
                  <span>Performance</span>
                  {getSortIcon('performance_score')}
                </div>
              </th>
              <th
                className="cursor-pointer px-4 py-3 hover:bg-slate-100 text-right"
                onClick={() => handleSort('salary')}
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Annual Salary</span>
                  {getSortIcon('salary')}
                </div>
              </th>
              <th className="px-4 py-3 text-center">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {paginatedRecords.length === 0 ? (
              <tr>
                <td colSpan={10} className="px-6 py-8 text-center text-slate-500">
                  No employee records matched the selected criteria.
                </td>
              </tr>
            ) : (
              paginatedRecords.map((rec) => (
                <tr
                  key={rec.employee_id}
                  className="hover:bg-slate-50/80 transition-colors"
                >
                  <td className="px-4 py-3 font-semibold text-slate-900">
                    {rec.employee_id}
                  </td>
                  <td className="px-4 py-3 text-slate-700">
                    {rec.years_experience} yrs
                  </td>
                  <td className="px-4 py-3 text-slate-700">
                    <span className="inline-block rounded-md bg-slate-100 px-2 py-0.5 text-[11px] font-medium text-slate-800">
                      {rec.education_level}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-900 max-w-[180px] truncate">
                    {rec.job_role}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {rec.department}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {rec.skills_count}
                  </td>
                  <td className="px-4 py-3 text-slate-600">
                    {rec.certifications}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-bold ${
                        rec.performance_score >= 90
                          ? 'bg-emerald-100 text-emerald-800'
                          : rec.performance_score >= 80
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {rec.performance_score}/100
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-slate-900">
                    {formatCurrency(rec.salary)}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button
                      type="button"
                      onClick={() => setSelectedEmployee(rec)}
                      className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 shadow-xs hover:bg-slate-50 hover:text-indigo-600 transition-colors"
                      title="View employee full details"
                    >
                      <Eye className="h-3 w-3" />
                      <span>Details</span>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-t border-slate-100 px-4 py-3 gap-2">
        <div className="text-xs text-slate-500">
          Showing <span className="font-semibold text-slate-800">{(currentPage - 1) * pageSize + 1}</span> to{' '}
          <span className="font-semibold text-slate-800">
            {Math.min(currentPage * pageSize, filteredRecords.length)}
          </span>{' '}
          of <span className="font-semibold text-slate-800">{filteredRecords.length}</span> filtered employees
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="h-3.5 w-3.5" />
            <span>Prev</span>
          </button>
          <span className="text-xs font-medium text-slate-700">
            Page {currentPage} of {totalPages}
          </span>
          <button
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="inline-flex items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 py-1 text-xs font-medium text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <span>Next</span>
            <ChevronRight className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Details Modal */}
      {selectedEmployee && (
        <EmployeeDetails
          employee={selectedEmployee}
          departmentAverage={departmentAvg}
          onClose={() => setSelectedEmployee(null)}
        />
      )}
    </div>
  );
};
