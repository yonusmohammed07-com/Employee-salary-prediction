import React, { useRef } from 'react';
import { Menu, Upload, RefreshCw, AlertCircle, Download } from 'lucide-react';
import { NavigationTab } from './Sidebar';
import { ReportButton } from './ReportButton';
import { CleanEmployeeRecord, TrainedModelsState, PredictionResult, SalaryInsights } from '../types';

interface HeaderProps {
  currentTab: NavigationTab;
  onOpenMobileMenu: () => void;
  records: CleanEmployeeRecord[];
  modelsState: TrainedModelsState;
  latestPrediction: PredictionResult | null;
  insights: SalaryInsights;
  onFileUpload: (file: File) => void;
  onReloadDefault: () => void;
  isLoading: boolean;
  datasetError: string | null;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenMobileMenu,
  records,
  modelsState,
  latestPrediction,
  insights,
  onFileUpload,
  onReloadDefault,
  isLoading,
  datasetError
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getPageMeta = () => {
    switch (currentTab) {
      case 'dashboard':
        return {
          title: 'Executive Salary Dashboard',
          subtitle: 'Real-time statistical overview and demographic compensation patterns'
        };
      case 'predictor':
        return {
          title: 'Salary Predictor Engine',
          subtitle: 'Estimate annual compensation using trained machine learning regression models'
        };
      case 'analysis':
        return {
          title: 'Salary & Employee Analytics',
          subtitle: 'Detailed breakdown across experience, education, departments, and roles'
        };
      case 'performance':
        return {
          title: 'Model Performance & Validation',
          subtitle: 'Evaluation metrics, test predictions, residuals, and feature importance'
        };
    }
  };

  const { title, subtitle } = getPageMeta();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileUpload(file);
      // Reset input so re-selecting same file triggers change
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-xs">
      <div className="flex flex-col gap-4 px-4 py-3.5 sm:px-6 sm:py-4 md:flex-row md:items-center md:justify-between">
        {/* Left: Mobile menu toggle + Titles */}
        <div className="flex items-center gap-3">
          <button
            id="btn-mobile-menu"
            type="button"
            onClick={onOpenMobileMenu}
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100 md:hidden"
            aria-label="Open sidebar"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">
              {title}
            </h1>
            <p className="text-xs text-slate-500 sm:text-sm">{subtitle}</p>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Hidden File Input for Custom CSV upload */}
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            className="hidden"
            onChange={handleFileChange}
          />

          <button
            id="btn-upload-csv"
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-50 transition-colors"
            title="Upload custom CSV dataset"
          >
            <Upload className="h-3.5 w-3.5 text-slate-500" />
            <span className="hidden sm:inline">Upload CSV</span>
          </button>

          <button
            id="btn-reload-data"
            type="button"
            onClick={onReloadDefault}
            disabled={isLoading}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 shadow-xs hover:bg-slate-50 disabled:opacity-50 transition-colors"
            title="Reset to default employee_salaries.csv"
          >
            <RefreshCw className={`h-3.5 w-3.5 text-slate-500 ${isLoading ? 'animate-spin' : ''}`} />
            <span className="hidden sm:inline">Reset Data</span>
          </button>

          {/* PDF Report Download */}
          <ReportButton
            records={records}
            modelsState={modelsState}
            latestPrediction={latestPrediction}
            insights={insights}
          />

          {/* Project Source ZIP Download */}
          <a
            id="btn-download-zip"
            href="/payintel-ml-source.zip"
            download="payintel-ml-source.zip"
            className="inline-flex items-center gap-1.5 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-xs font-semibold text-indigo-700 shadow-xs hover:bg-indigo-100 transition-colors"
            title="Download full project source code as a .zip file"
          >
            <Download className="h-3.5 w-3.5 text-indigo-600" />
            <span>Download ZIP</span>
          </a>
        </div>
      </div>

      {datasetError && (
        <div className="flex items-center gap-2 border-t border-rose-200 bg-rose-50 px-6 py-2 text-xs font-medium text-rose-800">
          <AlertCircle className="h-4 w-4 shrink-0 text-rose-600" />
          <span>{datasetError}</span>
        </div>
      )}
    </header>
  );
};
