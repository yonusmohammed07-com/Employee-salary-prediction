import React from 'react';
import { CheckCircle2, Award, ArrowDown, ArrowUp } from 'lucide-react';
import { ModelMetrics as MetricsType } from '../types';
import { formatCurrency } from '../utils/salaryAnalysis';

interface ModelMetricsProps {
  linearMetrics: MetricsType | null;
  rfMetrics: MetricsType | null;
  activeModelType: 'Linear Regression' | 'Random Forest Regression';
  onSelectModel: (model: 'Linear Regression' | 'Random Forest Regression') => void;
}

export const ModelMetrics: React.FC<ModelMetricsProps> = ({
  linearMetrics,
  rfMetrics,
  activeModelType,
  onSelectModel
}) => {
  if (!linearMetrics || !rfMetrics) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 text-center text-slate-500">
        Training evaluation metrics in progress...
      </div>
    );
  }

  // Determine better model per metric
  const maeWinner = rfMetrics.mae < linearMetrics.mae ? 'Random Forest' : 'Linear Regression';
  const rmseWinner = rfMetrics.rmse < linearMetrics.rmse ? 'Random Forest' : 'Linear Regression';
  const r2Winner = rfMetrics.r2 >= linearMetrics.r2 ? 'Random Forest' : 'Linear Regression';

  // Overall winner based on test R2
  const overallWinner =
    rfMetrics.r2 >= linearMetrics.r2 ? 'Random Forest Regression' : 'Linear Regression';

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 mb-5 gap-3">
        <div>
          <h3 className="text-base font-bold text-slate-900">
            Out-of-Sample Test Evaluation Metrics (20% Holdout)
          </h3>
          <p className="text-xs text-slate-500">
            Strict validation conducted on unseen testing records to prevent data leakage and overfitting.
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-800 border border-emerald-200">
          <Award className="h-3.5 w-3.5 text-emerald-600" />
          <span>Champion: {overallWinner}</span>
        </div>
      </div>

      {/* Comparison Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold uppercase tracking-wider text-slate-700">
              <th className="px-4 py-3">Metric Name</th>
              <th className="px-4 py-3">Optimization Goal</th>
              <th
                className={`cursor-pointer px-4 py-3 transition-colors ${
                  activeModelType === 'Linear Regression' ? 'bg-indigo-50 font-bold text-indigo-900' : ''
                }`}
                onClick={() => onSelectModel('Linear Regression')}
              >
                <div className="flex items-center gap-1.5">
                  <span>Linear Regression</span>
                  {activeModelType === 'Linear Regression' && (
                    <CheckCircle2 className="h-3.5 w-3.5 text-indigo-600" />
                  )}
                </div>
              </th>
              <th
                className={`cursor-pointer px-4 py-3 transition-colors ${
                  activeModelType === 'Random Forest Regression' ? 'bg-indigo-50 font-bold text-indigo-900' : ''
                }`}
                onClick={() => onSelectModel('Random Forest Regression')}
              >
                <div className="flex items-center gap-1.5">
                  <span>Random Forest Regression</span>
                  {activeModelType === 'Random Forest Regression' && (
                    <CheckCircle2 className="h-3.5 w-3.5 text-indigo-600" />
                  )}
                </div>
              </th>
              <th className="px-4 py-3 text-right">Optimal Model</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {/* MAE */}
            <tr className="hover:bg-slate-50/70">
              <td className="px-4 py-3 font-semibold text-slate-900">
                Mean Absolute Error (MAE)
              </td>
              <td className="px-4 py-3 text-slate-500">
                <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-sm">
                  <ArrowDown className="h-3 w-3" /> Lower is Better
                </span>
              </td>
              <td className={`px-4 py-3 font-mono font-medium ${activeModelType === 'Linear Regression' ? 'bg-indigo-50/50' : ''}`}>
                {formatCurrency(linearMetrics.mae)}
              </td>
              <td className={`px-4 py-3 font-mono font-medium ${activeModelType === 'Random Forest Regression' ? 'bg-indigo-50/50' : ''}`}>
                {formatCurrency(rfMetrics.mae)}
              </td>
              <td className="px-4 py-3 text-right font-semibold text-emerald-700">
                {maeWinner}
              </td>
            </tr>

            {/* MSE */}
            <tr className="hover:bg-slate-50/70">
              <td className="px-4 py-3 font-semibold text-slate-900">
                Mean Squared Error (MSE)
              </td>
              <td className="px-4 py-3 text-slate-500">
                <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-sm">
                  <ArrowDown className="h-3 w-3" /> Lower is Better
                </span>
              </td>
              <td className={`px-4 py-3 font-mono font-medium ${activeModelType === 'Linear Regression' ? 'bg-indigo-50/50' : ''}`}>
                {linearMetrics.mse.toExponential(3)}
              </td>
              <td className={`px-4 py-3 font-mono font-medium ${activeModelType === 'Random Forest Regression' ? 'bg-indigo-50/50' : ''}`}>
                {rfMetrics.mse.toExponential(3)}
              </td>
              <td className="px-4 py-3 text-right font-semibold text-emerald-700">
                {rfMetrics.mse < linearMetrics.mse ? 'Random Forest' : 'Linear Regression'}
              </td>
            </tr>

            {/* RMSE */}
            <tr className="hover:bg-slate-50/70">
              <td className="px-4 py-3 font-semibold text-slate-900">
                Root Mean Squared Error (RMSE)
              </td>
              <td className="px-4 py-3 text-slate-500">
                <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-sm">
                  <ArrowDown className="h-3 w-3" /> Lower is Better
                </span>
              </td>
              <td className={`px-4 py-3 font-mono font-medium ${activeModelType === 'Linear Regression' ? 'bg-indigo-50/50' : ''}`}>
                {formatCurrency(linearMetrics.rmse)}
              </td>
              <td className={`px-4 py-3 font-mono font-medium ${activeModelType === 'Random Forest Regression' ? 'bg-indigo-50/50' : ''}`}>
                {formatCurrency(rfMetrics.rmse)}
              </td>
              <td className="px-4 py-3 text-right font-semibold text-emerald-700">
                {rmseWinner}
              </td>
            </tr>

            {/* R2 */}
            <tr className="hover:bg-slate-50/70">
              <td className="px-4 py-3 font-semibold text-slate-900">
                Coefficient of Determination (R²)
              </td>
              <td className="px-4 py-3 text-slate-500">
                <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-sm">
                  <ArrowUp className="h-3 w-3" /> Higher is Better
                </span>
              </td>
              <td className={`px-4 py-3 font-mono font-bold text-slate-900 ${activeModelType === 'Linear Regression' ? 'bg-indigo-50/50 text-indigo-700' : ''}`}>
                {(linearMetrics.r2 * 100).toFixed(1)}% ({linearMetrics.r2})
              </td>
              <td className={`px-4 py-3 font-mono font-bold text-slate-900 ${activeModelType === 'Random Forest Regression' ? 'bg-indigo-50/50 text-indigo-700' : ''}`}>
                {(rfMetrics.r2 * 100).toFixed(1)}% ({rfMetrics.r2})
              </td>
              <td className="px-4 py-3 text-right font-semibold text-emerald-700">
                {r2Winner}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
};
