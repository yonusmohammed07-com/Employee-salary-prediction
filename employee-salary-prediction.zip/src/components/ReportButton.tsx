import React, { useState } from 'react';
import { Download, Loader2 } from 'lucide-react';
import { CleanEmployeeRecord, TrainedModelsState, PredictionResult, SalaryInsights } from '../types';
import { generatePdfReport } from '../utils/reportGenerator';

interface ReportButtonProps {
  records: CleanEmployeeRecord[];
  modelsState: TrainedModelsState;
  latestPrediction: PredictionResult | null;
  insights: SalaryInsights;
}

export const ReportButton: React.FC<ReportButtonProps> = ({
  records,
  modelsState,
  latestPrediction,
  insights
}) => {
  const [generating, setGenerating] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  const handleDownload = async () => {
    if (!modelsState.linear && !modelsState.randomForest) {
      alert('Train the model before generating the report.');
      return;
    }

    try {
      setGenerating(true);
      setMessage(null);
      await generatePdfReport({
        records,
        modelsState,
        latestPrediction,
        insights
      });
    } catch (err: any) {
      console.error(err);
      alert(err.message || 'Unable to generate report. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="relative inline-block">
      <button
        id="btn-download-report"
        onClick={handleDownload}
        disabled={generating || records.length === 0}
        className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white shadow-xs hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        title="Download Client-side PDF Report"
      >
        {generating ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin text-white" />
            <span>Generating PDF...</span>
          </>
        ) : (
          <>
            <Download className="h-4 w-4 text-white" />
            <span>Download Report</span>
          </>
        )}
      </button>
      {message && <div className="absolute right-0 top-full mt-1 text-xs text-rose-600">{message}</div>}
    </div>
  );
};
