import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from 'recharts';
import { PredictionPoint } from '../types';
import { analyzeResiduals } from '../utils/metrics';
import { formatCurrency } from '../utils/salaryAnalysis';

interface ResidualChartProps {
  testPredictions: PredictionPoint[];
  modelName: string;
}

export const ResidualChart: React.FC<ResidualChartProps> = ({
  testPredictions,
  modelName
}) => {
  const residuals = useMemo(
    () => testPredictions.map((p) => p.residual),
    [testPredictions]
  );

  const analysis = useMemo(() => analyzeResiduals(residuals), [residuals]);

  return (
    <div className="rounded-xl border border-slate-200 bg-white p-6 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 pb-4 mb-5 gap-2">
        <div>
          <h3 className="text-base font-bold text-slate-900">
            Residual Error Distribution &amp; Bias Analysis
          </h3>
          <p className="text-xs text-slate-500">
            Evaluating error delta: <code className="text-indigo-600">Residual = Actual Salary - Predicted Salary</code> for {modelName}
          </p>
        </div>
        <span
          className={`inline-flex items-center rounded-md px-2.5 py-1 text-xs font-semibold ${
            analysis.biasTendency === 'Balanced'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-amber-50 text-amber-800 border border-amber-200'
          }`}
        >
          Model Bias: {analysis.biasTendency}
        </span>
      </div>

      {/* Residual Diagnostics Metrics */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 mb-6">
        <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
          <span className="text-xs text-slate-500">Mean Residual Error</span>
          <div className="text-sm font-bold text-slate-900 mt-1">
            {formatCurrency(analysis.averageResidual)}
          </div>
          <span className="text-[10px] text-slate-400">Target close to ₹0</span>
        </div>

        <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
          <span className="text-xs text-slate-500">Underestimated Count</span>
          <div className="text-sm font-bold text-indigo-600 mt-1">
            {analysis.positiveCount} employees
          </div>
          <span className="text-[10px] text-slate-400">Actual &gt; Predicted</span>
        </div>

        <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
          <span className="text-xs text-slate-500">Overestimated Count</span>
          <div className="text-sm font-bold text-amber-600 mt-1">
            {analysis.negativeCount} employees
          </div>
          <span className="text-[10px] text-slate-400">Actual &lt; Predicted</span>
        </div>

        <div className="rounded-lg border border-slate-100 bg-slate-50 p-3">
          <span className="text-xs text-slate-500">Near-Exact Predictions</span>
          <div className="text-sm font-bold text-emerald-600 mt-1">
            {analysis.zeroCount} employees
          </div>
          <span className="text-[10px] text-slate-400">Within &plusmn;₹1,000</span>
        </div>
      </div>

      {/* Histogram Chart */}
      <div className="h-64 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={analysis.distribution} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis
              dataKey="bin"
              tick={{ fontSize: 10, fill: '#64748b' }}
              interval={0}
              angle={-20}
              textAnchor="end"
            />
            <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
            <Tooltip
              formatter={(value: any) => [`${value} test records`, 'Frequency']}
              labelFormatter={(label) => `Residual Range: ${label}`}
              contentStyle={{
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderRadius: '8px',
                fontSize: '12px'
              }}
            />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {analysis.distribution.map((entry, index) => (
                <Cell
                  key={`cell-${index}`}
                  fill={
                    index === Math.floor(analysis.distribution.length / 2)
                      ? '#4f46e5'
                      : '#94a3b8'
                  }
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
