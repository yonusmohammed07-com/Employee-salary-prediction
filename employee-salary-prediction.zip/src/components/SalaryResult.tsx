import React from 'react';
import {
  TrendingUp,
  ShieldCheck,
  Briefcase,
  GraduationCap,
  Building,
  Layers,
  Award,
  Info
} from 'lucide-react';
import { PredictionResult } from '../types';
import { formatCurrency } from '../utils/salaryAnalysis';

interface SalaryResultProps {
  result: PredictionResult | null;
}

export const SalaryResult: React.FC<SalaryResultProps> = ({ result }) => {
  if (!result) {
    return (
      <div
        id="salary-result-placeholder"
        className="flex flex-col items-center justify-center rounded-xl border border-dashed border-slate-300 bg-slate-50/50 p-12 text-center"
      >
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-slate-200 text-slate-500">
          <TrendingUp className="h-6 w-6" />
        </div>
        <h4 className="mt-4 text-base font-semibold text-slate-800">
          No Salary Prediction Generated Yet
        </h4>
        <p className="mt-1 max-w-sm text-xs text-slate-500">
          Complete the employee profile details on the left and click &ldquo;Predict Salary&rdquo; to execute the machine learning inference engine.
        </p>
      </div>
    );
  }

  return (
    <div
      id="salary-prediction-result-card"
      className="overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xs transition-all"
    >
      {/* Top Banner */}
      <div className="border-b border-indigo-100 bg-indigo-50/70 px-6 py-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="inline-flex items-center gap-1.5 rounded-md bg-indigo-100/80 px-2.5 py-1 text-xs font-semibold text-indigo-800">
            <ShieldCheck className="h-3.5 w-3.5 text-indigo-600" />
            Model: {result.modelUsed}
          </span>
          <span className="text-xs font-medium text-slate-500">
            Confidence Index: <strong className="text-slate-800">{result.confidenceScore}%</strong>
          </span>
        </div>
      </div>

      {/* Main Big Output */}
      <div className="px-6 py-6 sm:px-8 sm:py-8">
        <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
          Estimated Annual Salary
        </span>
        <div className="mt-2 flex flex-wrap items-baseline gap-3">
          <span className="text-3xl font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            {formatCurrency(result.predictedSalary)}
          </span>
          <span className="text-xs font-medium text-slate-500">/ year</span>
        </div>

        {/* Dynamic Estimated Salary Range */}
        <div className="mt-4 rounded-lg bg-slate-50 p-4 border border-slate-100">
          <div className="flex items-center justify-between text-xs text-slate-600">
            <span className="font-semibold text-slate-700">Calculated Expected Salary Range:</span>
            <span className="font-bold text-indigo-600">
              {formatCurrency(result.lowerBound)} – {formatCurrency(result.upperBound)}
            </span>
          </div>
          <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full rounded-full bg-indigo-600"
              style={{ width: `${Math.min(100, Math.max(30, result.confidenceScore))}%` }}
            />
          </div>
          <p className="mt-2 text-[11px] text-slate-500">
            Range derived from test-set residual dispersion &amp; root mean square error (RMSE).
          </p>
        </div>

        {/* Profile Breakdown Badges */}
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3">
          <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <Briefcase className="h-3.5 w-3.5 text-slate-400" />
              <span>Job Role</span>
            </div>
            <div className="mt-1 font-semibold text-slate-900 text-xs truncate">
              {result.inputs.job_role}
            </div>
          </div>

          <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <Building className="h-3.5 w-3.5 text-slate-400" />
              <span>Department</span>
            </div>
            <div className="mt-1 font-semibold text-slate-900 text-xs truncate">
              {result.inputs.department}
            </div>
          </div>

          <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <GraduationCap className="h-3.5 w-3.5 text-slate-400" />
              <span>Education</span>
            </div>
            <div className="mt-1 font-semibold text-slate-900 text-xs truncate">
              {result.inputs.education_level}
            </div>
          </div>

          <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <Layers className="h-3.5 w-3.5 text-slate-400" />
              <span>Experience</span>
            </div>
            <div className="mt-1 font-semibold text-slate-900 text-xs">
              {result.inputs.years_experience} yrs ({result.experience_group})
            </div>
          </div>

          <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <Award className="h-3.5 w-3.5 text-slate-400" />
              <span>Career Level</span>
            </div>
            <div className="mt-1 font-semibold text-slate-900 text-xs">
              {result.career_level} Level
            </div>
          </div>

          <div className="rounded-lg border border-slate-100 bg-slate-50/50 p-3">
            <div className="flex items-center gap-1.5 text-xs text-slate-500">
              <TrendingUp className="h-3.5 w-3.5 text-slate-400" />
              <span>Skill Density</span>
            </div>
            <div className="mt-1 font-semibold text-slate-900 text-xs">
              {result.skill_density} skills/yr
            </div>
          </div>
        </div>

        {/* Disclaimer per requirement Section 16 & 17 */}
        <div className="mt-6 flex items-start gap-2.5 rounded-lg border border-amber-200 bg-amber-50/60 p-3.5 text-xs text-amber-800">
          <Info className="h-4 w-4 shrink-0 text-amber-600 mt-0.5" />
          <span>
            <strong>Disclaimer:</strong> This predicted salary is an automated statistical estimate generated by browser regression models from historical dataset trends. It does not constitute a guaranteed compensation offer or contractual salary.
          </span>
        </div>
      </div>
    </div>
  );
};
