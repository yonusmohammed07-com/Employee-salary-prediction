import React from 'react';
import {
  LayoutDashboard,
  Calculator,
  BarChart3,
  Cpu,
  Database,
  FileSpreadsheet
} from 'lucide-react';

export type NavigationTab = 'dashboard' | 'predictor' | 'analysis' | 'performance';

interface SidebarProps {
  currentTab: NavigationTab;
  onTabChange: (tab: NavigationTab) => void;
  employeeCount: number;
  isModelTrained: boolean;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  employeeCount,
  isModelTrained,
  isOpenMobile,
  onCloseMobile
}) => {
  const navItems = [
    {
      id: 'dashboard' as NavigationTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      description: 'Overview & Key Metrics'
    },
    {
      id: 'predictor' as NavigationTab,
      label: 'Salary Predictor',
      icon: Calculator,
      description: 'ML Salary Estimation'
    },
    {
      id: 'analysis' as NavigationTab,
      label: 'Salary Analysis',
      icon: BarChart3,
      description: 'Employee Directory & Trends'
    },
    {
      id: 'performance' as NavigationTab,
      label: 'Model Performance',
      icon: Cpu,
      description: 'Regression Metrics & Residuals'
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 backdrop-blur-xs md:hidden"
          onClick={onCloseMobile}
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-50 flex w-72 flex-col border-r border-slate-200 bg-slate-900 text-slate-100 transition-transform duration-200 ease-in-out md:static md:translate-x-0 ${
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand */}
        <div className="flex items-center gap-3 border-b border-slate-800 px-6 py-5">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-600 text-white shadow-xs">
            <FileSpreadsheet className="h-5 w-5" />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight text-white leading-tight">
              PayIntel ML
            </h1>
            <p className="text-xs text-slate-400">Employee Salary Prediction</p>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 space-y-1.5 px-3 py-6">
          <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
            Platform Modules
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => {
                  onTabChange(item.id);
                  onCloseMobile();
                }}
                className={`group flex w-full items-center gap-3.5 rounded-lg px-3.5 py-3 text-left transition-colors ${
                  isActive
                    ? 'bg-indigo-600 text-white font-medium shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon
                  className={`h-5 w-5 shrink-0 ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium leading-none">{item.label}</div>
                  <div
                    className={`mt-1 truncate text-xs ${
                      isActive ? 'text-indigo-100' : 'text-slate-400'
                    }`}
                  >
                    {item.description}
                  </div>
                </div>
              </button>
            );
          })}
        </nav>

        {/* System & Data Status Badge */}
        <div className="border-t border-slate-800 p-4">
          <div className="rounded-lg bg-slate-800/80 p-3 text-xs">
            <div className="flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Database className="h-3.5 w-3.5 text-indigo-400" />
                Dataset Size:
              </span>
              <span className="font-semibold text-white">{employeeCount} records</span>
            </div>
            <div className="mt-2 flex items-center justify-between text-slate-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Cpu className="h-3.5 w-3.5 text-emerald-400" />
                Model Engine:
              </span>
              <span
                className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-medium ${
                  isModelTrained
                    ? 'bg-emerald-500/20 text-emerald-300'
                    : 'bg-amber-500/20 text-amber-300'
                }`}
              >
                {isModelTrained ? 'Trained (Ready)' : 'Training...'}
              </span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
