import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  id?: string;
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  badge?: string;
  badgeType?: 'neutral' | 'success' | 'indigo' | 'amber';
}

export const StatCard: React.FC<StatCardProps> = ({
  id,
  title,
  value,
  subtitle,
  icon: Icon,
  badge,
  badgeType = 'neutral'
}) => {
  const badgeStyles = {
    neutral: 'bg-slate-100 text-slate-700',
    success: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200'
  };

  return (
    <div
      id={id}
      className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-xs transition-all hover:border-slate-300"
    >
      <div className="flex items-start justify-between gap-2">
        <span className="text-xs font-semibold tracking-wider text-slate-500 uppercase">
          {title}
        </span>
        <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-slate-100 text-slate-700">
          <Icon className="h-4 w-4" />
        </div>
      </div>

      <div className="mt-3">
        <div className="text-2xl font-bold tracking-tight text-slate-900 truncate">
          {value}
        </div>
        {subtitle && (
          <p className="mt-1 text-xs text-slate-500 line-clamp-1">{subtitle}</p>
        )}
      </div>

      {badge && (
        <div className="mt-3 pt-3 border-t border-slate-100">
          <span
            className={`inline-block rounded-md border px-2 py-0.5 text-[11px] font-medium ${badgeStyles[badgeType]}`}
          >
            {badge}
          </span>
        </div>
      )}
    </div>
  );
};
