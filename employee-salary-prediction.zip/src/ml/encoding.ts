import { CleanEmployeeRecord } from '../types';

export const EDUCATION_ORDINAL_MAP: Record<string, number> = {
  'high school': 1,
  'diploma': 2,
  "bachelor's": 3,
  'bachelor': 3,
  'bachelors': 3,
  "master's": 4,
  'master': 4,
  'masters': 4,
  'doctorate': 5,
  'phd': 5
};

export const COMPANY_SIZE_MAP: Record<string, number> = {
  small: 1,
  medium: 2,
  large: 3
};

export const CAREER_LEVEL_MAP: Record<string, number> = {
  entry: 1,
  junior: 2,
  mid: 3,
  senior: 4,
  expert: 5
};

export interface CategoryEncoders {
  departmentMap: Record<string, number>;
  jobRoleMap: Record<string, number>;
  departmentsList: string[];
  jobRolesList: string[];
  featureNames: string[];
}

export function buildEncoders(records: CleanEmployeeRecord[]): CategoryEncoders {
  const departmentsList = Array.from(new Set(records.map((r) => r.department))).sort();
  const jobRolesList = Array.from(new Set(records.map((r) => r.job_role))).sort();

  const departmentMap: Record<string, number> = {};
  departmentsList.forEach((dept, idx) => {
    departmentMap[dept.toLowerCase()] = idx + 1;
  });

  const jobRoleMap: Record<string, number> = {};
  jobRolesList.forEach((role, idx) => {
    jobRoleMap[role.toLowerCase()] = idx + 1;
  });

  const featureNames = [
    'Years of Experience',
    'Education Level',
    'Age',
    'Department',
    'Job Role',
    'Performance Score',
    'Skills Count',
    'Certifications',
    'Company Size',
    'Skill Density',
    'Career Level'
  ];

  return {
    departmentMap,
    jobRoleMap,
    departmentsList,
    jobRolesList,
    featureNames
  };
}

export function encodeRecord(
  item: {
    age: number;
    years_experience: number;
    education_level: string;
    job_role: string;
    department: string;
    skills_count: number;
    certifications: number;
    company_size: string;
    performance_score: number;
    skill_density?: number;
    career_level?: string;
  },
  encoders: CategoryEncoders
): number[] {
  const yearsExp = Number(item.years_experience);
  const eduLower = String(item.education_level || '').toLowerCase();
  const eduEncoded = EDUCATION_ORDINAL_MAP[eduLower] || 3;

  const age = Number(item.age);
  const deptLower = String(item.department || '').toLowerCase();
  const deptEncoded = encoders.departmentMap[deptLower] || 1;

  const roleLower = String(item.job_role || '').toLowerCase();
  const roleEncoded = encoders.jobRoleMap[roleLower] || 1;

  const perf = Number(item.performance_score);
  const skills = Number(item.skills_count);
  const certs = Number(item.certifications);

  const sizeLower = String(item.company_size || '').toLowerCase();
  const sizeEncoded = COMPANY_SIZE_MAP[sizeLower] || 2;

  const skillDensity =
    item.skill_density !== undefined
      ? Number(item.skill_density)
      : skills / (yearsExp + 1);

  const careerLvlLower = String(item.career_level || '').toLowerCase();
  const careerEncoded =
    CAREER_LEVEL_MAP[careerLvlLower] ||
    (yearsExp <= 1 ? 1 : yearsExp <= 4 ? 2 : yearsExp <= 9 ? 3 : yearsExp <= 15 ? 4 : 5);

  return [
    yearsExp,
    eduEncoded,
    age,
    deptEncoded,
    roleEncoded,
    perf,
    skills,
    certs,
    sizeEncoded,
    skillDensity,
    careerEncoded
  ];
}
