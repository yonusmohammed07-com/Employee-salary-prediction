export type ExperienceGroup =
  | "0–2 years"
  | "3–5 years"
  | "6–10 years"
  | "11–15 years"
  | "16+ years";

export type CareerLevel =
  | "Entry"
  | "Junior"
  | "Mid"
  | "Senior"
  | "Expert";

export interface DerivedFeatures {
  experience_group: ExperienceGroup;
  career_level: CareerLevel;
  skill_density: number;
}

export function getExperienceGroup(years: number): ExperienceGroup {
  if (years <= 2) return "0–2 years";
  if (years <= 5) return "3–5 years";
  if (years <= 10) return "6–10 years";
  if (years <= 15) return "11–15 years";
  return "16+ years";
}

export function getCareerLevel(years: number): CareerLevel {
  if (years <= 1) return "Entry";
  if (years <= 4) return "Junior";
  if (years <= 9) return "Mid";
  if (years <= 15) return "Senior";
  return "Expert";
}

export function calculateSkillDensity(skillsCount: number, yearsExp: number): number {
  const density = skillsCount / (Math.max(0, yearsExp) + 1);
  return Math.round(density * 100) / 100;
}

export function engineerFeatures(input: {
  years_experience: number;
  skills_count: number;
}): DerivedFeatures {
  const expGroup = getExperienceGroup(input.years_experience);
  const careerLvl = getCareerLevel(input.years_experience);
  const density = calculateSkillDensity(input.skills_count, input.years_experience);

  return {
    experience_group: expGroup,
    career_level: careerLvl,
    skill_density: density
  };
}
