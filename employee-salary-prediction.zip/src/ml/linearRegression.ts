import { FeatureImportanceItem } from '../types';

export class LinearRegressionModel {
  private weights: number[] = [];
  private bias: number = 0;
  private featureMeans: number[] = [];
  private featureStds: number[] = [];
  private featureNames: string[] = [];

  constructor(featureNames: string[] = []) {
    this.featureNames = featureNames;
  }

  fit(X: number[][], y: number[]): void {
    const nSamples = X.length;
    const nFeatures = X[0].length;

    if (nSamples === 0 || nFeatures === 0) {
      throw new Error('Insufficient data for Linear Regression training');
    }

    // Step 1: Compute means and standard deviations for feature scaling
    this.featureMeans = new Array(nFeatures).fill(0);
    this.featureStds = new Array(nFeatures).fill(0);

    for (let j = 0; j < nFeatures; j++) {
      let sum = 0;
      for (let i = 0; i < nSamples; i++) {
        sum += X[i][j];
      }
      this.featureMeans[j] = sum / nSamples;

      let varSum = 0;
      for (let i = 0; i < nSamples; i++) {
        const diff = X[i][j] - this.featureMeans[j];
        varSum += diff * diff;
      }
      this.featureStds[j] = Math.sqrt(varSum / nSamples) || 1.0;
    }

    // Standardize X and add intercept term (bias)
    // Augmented matrix X_aug of shape [nSamples, nFeatures + 1] where last column is 1
    const X_norm: number[][] = [];
    for (let i = 0; i < nSamples; i++) {
      const row = new Array(nFeatures + 1);
      for (let j = 0; j < nFeatures; j++) {
        row[j] = (X[i][j] - this.featureMeans[j]) / this.featureStds[j];
      }
      row[nFeatures] = 1.0; // Intercept
      X_norm.push(row);
    }

    const nParams = nFeatures + 1;

    // Compute (X^T * X + lambda * I)
    const XtX: number[][] = Array.from({ length: nParams }, () => new Array(nParams).fill(0));
    const Xty: number[] = new Array(nParams).fill(0);

    const lambda = 1e-3; // Ridge regularization for numerical stability

    for (let i = 0; i < nSamples; i++) {
      const xi = X_norm[i];
      const yi = y[i];
      for (let r = 0; r < nParams; r++) {
        Xty[r] += xi[r] * yi;
        for (let c = 0; c < nParams; c++) {
          XtX[r][c] += xi[r] * xi[c];
        }
      }
    }

    // Regularize diagonal (except intercept)
    for (let r = 0; r < nFeatures; r++) {
      XtX[r][r] += lambda;
    }

    // Solve XtX * params = Xty using Gaussian Elimination with partial pivoting
    const params = this.solveLinearSystem(XtX, Xty);

    this.weights = params.slice(0, nFeatures);
    this.bias = params[nFeatures];
  }

  predict(x: number[]): number {
    let pred = this.bias;
    for (let j = 0; j < this.weights.length; j++) {
      const normalized = (x[j] - this.featureMeans[j]) / this.featureStds[j];
      pred += this.weights[j] * normalized;
    }
    return Math.max(0, pred);
  }

  getFeatureImportance(): FeatureImportanceItem[] {
    const absWeights = this.weights.map((w) => Math.abs(w));
    const total = absWeights.reduce((a, b) => a + b, 0) || 1;

    return this.weights.map((w, idx) => {
      const importance = Math.abs(w);
      const percentage = Math.round((importance / total) * 1000) / 10;
      return {
        feature: this.featureNames[idx] || `Feature ${idx + 1}`,
        importance: Math.round(importance),
        percentage
      };
    }).sort((a, b) => b.importance - a.importance);
  }

  private solveLinearSystem(A: number[][], b: number[]): number[] {
    const n = b.length;
    // Clone matrix and vector to prevent mutation
    const M: number[][] = A.map((row) => [...row]);
    const x: number[] = [...b];

    for (let p = 0; p < n; p++) {
      // Find pivot
      let maxRow = p;
      for (let r = p + 1; r < n; r++) {
        if (Math.abs(M[r][p]) > Math.abs(M[maxRow][p])) {
          maxRow = r;
        }
      }

      // Swap rows
      const tempRow = M[p];
      M[p] = M[maxRow];
      M[maxRow] = tempRow;

      const tempVal = x[p];
      x[p] = x[maxRow];
      x[maxRow] = tempVal;

      const pivot = M[p][p];
      if (Math.abs(pivot) < 1e-12) {
        continue;
      }

      for (let r = p + 1; r < n; r++) {
        const factor = M[r][p] / pivot;
        x[r] -= factor * x[p];
        for (let c = p; c < n; c++) {
          M[r][c] -= factor * M[p][c];
        }
      }
    }

    // Back-substitution
    const sol = new Array(n).fill(0);
    for (let r = n - 1; r >= 0; r--) {
      let sum = x[r];
      for (let c = r + 1; c < n; c++) {
        sum -= M[r][c] * sol[c];
      }
      sol[r] = M[r][r] !== 0 ? sum / M[r][r] : 0;
    }

    return sol;
  }
}
