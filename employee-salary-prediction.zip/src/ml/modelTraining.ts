import { CleanEmployeeRecord, TrainedModelResult, PredictionPoint } from '../types';
import { CategoryEncoders, encodeRecord } from './encoding';
import { LinearRegressionModel } from './linearRegression';
import { RandomForestRegressorModel } from './randomForest';
import { calculateRegressionMetrics } from '../utils/metrics';

export interface TrainAllModelsResult {
  linear: TrainedModelResult;
  randomForest: TrainedModelResult;
  trainCount: number;
  testCount: number;
}

export async function trainAndEvaluateModels(
  records: CleanEmployeeRecord[],
  encoders: CategoryEncoders,
  onProgress?: (percent: number) => void
): Promise<TrainAllModelsResult> {
  if (records.length < 10) {
    throw new Error('Insufficient records for training (minimum 10 required).');
  }

  onProgress?.(10);

  // Shuffle copy of records deterministically with pseudo-random seed
  const shuffled = [...records];
  let seed = 42;
  const pseudoRandom = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(pseudoRandom() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }

  // 80% Train, 20% Test split
  const trainSize = Math.floor(shuffled.length * 0.8);
  const trainData = shuffled.slice(0, trainSize);
  const testData = shuffled.slice(trainSize);

  // Build feature matrices
  const X_train = trainData.map((r) => encodeRecord(r, encoders));
  const y_train = trainData.map((r) => r.salary);

  const X_test = testData.map((r) => encodeRecord(r, encoders));
  const y_test = testData.map((r) => r.salary);

  onProgress?.(30);

  // 1. Train Linear Regression
  const linearModel = new LinearRegressionModel(encoders.featureNames);
  linearModel.fit(X_train, y_train);

  onProgress?.(55);

  // Generate test predictions for Linear Regression
  const linearTestPreds: PredictionPoint[] = testData.map((record, i) => {
    const pred = Math.round(linearModel.predict(X_test[i]));
    return {
      id: record.employee_id,
      actual: record.salary,
      predicted: pred,
      residual: record.salary - pred,
      role: record.job_role,
      dept: record.department
    };
  });

  const linearMetrics = calculateRegressionMetrics(
    y_test,
    linearTestPreds.map((p) => p.predicted)
  );

  const linearImportance = linearModel.getFeatureImportance();

  onProgress?.(70);

  // 2. Train Random Forest Regressor
  const rfModel = new RandomForestRegressorModel(16, 6, 4, encoders.featureNames);
  rfModel.fit(X_train, y_train);

  onProgress?.(85);

  // Generate test predictions for Random Forest
  const rfTestPreds: PredictionPoint[] = testData.map((record, i) => {
    const pred = Math.round(rfModel.predict(X_test[i]));
    return {
      id: record.employee_id,
      actual: record.salary,
      predicted: pred,
      residual: record.salary - pred,
      role: record.job_role,
      dept: record.department
    };
  });

  const rfMetrics = calculateRegressionMetrics(
    y_test,
    rfTestPreds.map((p) => p.predicted)
  );

  const rfImportance = rfModel.getFeatureImportance();

  onProgress?.(100);

  return {
    trainCount: trainData.length,
    testCount: testData.length,
    linear: {
      modelType: 'Linear Regression',
      metrics: linearMetrics,
      testPredictions: linearTestPreds,
      featureImportance: linearImportance,
      predict: (feat: number[]) => Math.round(linearModel.predict(feat))
    },
    randomForest: {
      modelType: 'Random Forest Regression',
      metrics: rfMetrics,
      testPredictions: rfTestPreds,
      featureImportance: rfImportance,
      predict: (feat: number[]) => Math.round(rfModel.predict(feat))
    }
  };
}
