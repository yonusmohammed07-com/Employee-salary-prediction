import { RawEmployeeRecord, CleanEmployeeRecord } from '../types';
import { engineerFeatures } from './featureEngineering';

export interface PreprocessingResult {
  validRecords: CleanEmployeeRecord[];
  discardedCount: number;
  departments: string[];
  jobRoles: string[];
  educationLevels: string[];
  companySizes: string[];
  error?: string;
}

export const REQUIRED_FIELDS = [
  'years_experience',
  'education_level',
  'job_role',
  'department',
  'salary'
];

export function preprocessDataset(rawRecords: RawEmployeeRecord[]): PreprocessingResult {
  if (!rawRecords || rawRecords.length === 0) {
    return {
      validRecords: [],
      discardedCount: 0,
      departments: [],
      jobRoles: [],
      educationLevels: [],
      companySizes: [],
      error: 'Dataset is empty.'
    };
  }

  // Check required fields in the first record
  const sample = rawRecords[0];
  const missingFields = REQUIRED_FIELDS.filter((f) => sample[f] === undefined);
  if (missingFields.length > 0) {
    return {
      validRecords: [],
      discardedCount: 0,
      departments: [],
      jobRoles: [],
      educationLevels: [],
      companySizes: [],
      error: `Missing required columns: ${missingFields.join(', ')}`
    };
  }

  const seenIds = new Set<string>();
  const validRecords: CleanEmployeeRecord[] = [];
  let discardedCount = 0;

  for (let i = 0; i < rawRecords.length; i++) {
    const row = rawRecords[i];

    // Clean & normalize employee ID
    const rawId = String(row.employee_id || `EMP_${i + 1}`).trim();
    if (seenIds.has(rawId)) {
      discardedCount++;
      continue;
    }

    // Numerical conversions
    const age = Number(row.age);
    const yearsExp = Number(row.years_experience);
    const skillsCount = Number(row.skills_count ?? 0);
    const certs = Number(row.certifications ?? 0);
    const perfScore = Number(row.performance_score ?? 75);
    const salary = Number(row.salary);

    // Range Validations according to requirements:
    // Age: 18–100 (or if missing, fallback to 22 + yearsExp)
    const validAge = !isNaN(age) ? age : 22 + (isNaN(yearsExp) ? 2 : yearsExp);
    if (validAge < 18 || validAge > 100) {
      discardedCount++;
      continue;
    }

    // Years Experience: 0–60
    if (isNaN(yearsExp) || yearsExp < 0 || yearsExp > 60) {
      discardedCount++;
      continue;
    }

    // Skills Count: >= 0
    if (isNaN(skillsCount) || skillsCount < 0) {
      discardedCount++;
      continue;
    }

    // Certifications: >= 0
    if (isNaN(certs) || certs < 0) {
      discardedCount++;
      continue;
    }

    // Performance Score: 0–100
    if (isNaN(perfScore) || perfScore < 0 || perfScore > 100) {
      discardedCount++;
      continue;
    }

    // Salary: > 0
    if (isNaN(salary) || salary <= 0) {
      discardedCount++;
      continue;
    }

    // Categorical normalization
    const education = String(row.education_level || "Bachelor's").trim();
    const jobRole = String(row.job_role || '').trim();
    const department = String(row.department || '').trim();
    const companySize = String(row.company_size || 'Medium').trim();
    const gender = String(row.gender || 'Not Specified').trim();

    if (!jobRole || !department) {
      discardedCount++;
      continue;
    }

    seenIds.add(rawId);

    // Feature engineering
    const derived = engineerFeatures({
      years_experience: yearsExp,
      skills_count: skillsCount
    });

    validRecords.push({
      employee_id: rawId,
      age: Math.round(validAge),
      gender,
      years_experience: yearsExp,
      education_level: education,
      job_role: jobRole,
      department,
      skills_count: Math.round(skillsCount),
      certifications: Math.round(certs),
      company_size: companySize,
      performance_score: Math.round(perfScore),
      salary: Math.round(salary),
      experience_group: derived.experience_group,
      career_level: derived.career_level,
      skill_density: derived.skill_density
    });
  }

  // Extract unique distinct categories
  const departments = Array.from(new Set(validRecords.map((r) => r.department))).sort();
  const jobRoles = Array.from(new Set(validRecords.map((r) => r.job_role))).sort();
  const educationLevels = ["High School", "Diploma", "Bachelor's", "Master's", "Doctorate"].filter(
    (lvl) => validRecords.some((r) => r.education_level.toLowerCase() === lvl.toLowerCase())
  );
  if (educationLevels.length === 0) {
    educationLevels.push("High School", "Diploma", "Bachelor's", "Master's", "Doctorate");
  }
  const companySizes = ['Small', 'Medium', 'Large'];

  return {
    validRecords,
    discardedCount,
    departments,
    jobRoles,
    educationLevels,
    companySizes
  };
}
