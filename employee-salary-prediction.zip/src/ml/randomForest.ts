import { FeatureImportanceItem } from '../types';

interface TreeNode {
  isLeaf: boolean;
  value?: number;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
}

class RegressionTree {
  root: TreeNode | null = null;
  maxDepth: number;
  minSamplesSplit: number;
  featureImportanceAccumulator: number[];

  constructor(maxDepth = 6, minSamplesSplit = 4, nFeatures = 11) {
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
    this.featureImportanceAccumulator = new Array(nFeatures).fill(0);
  }

  fit(X: number[][], y: number[]): void {
    this.root = this.buildTree(X, y, 0);
  }

  private buildTree(X: number[][], y: number[], depth: number): TreeNode {
    const nSamples = X.length;
    const nFeatures = X[0] ? X[0].length : 0;

    // Calculate leaf value (mean of y)
    const meanValue = y.reduce((a, b) => a + b, 0) / (nSamples || 1);

    if (nSamples <= this.minSamplesSplit || depth >= this.maxDepth) {
      return { isLeaf: true, value: meanValue };
    }

    // Variance of current node
    const currentVar = this.variance(y);
    if (currentVar < 1e-4) {
      return { isLeaf: true, value: meanValue };
    }

    // Random subset of features (Random Forest feature subsampling)
    const featureIndices: number[] = [];
    const maxFeaturesToTry = Math.max(3, Math.floor(Math.sqrt(nFeatures)) + 1);
    const shuffled = Array.from({ length: nFeatures }, (_, i) => i).sort(() => Math.random() - 0.5);
    for (let i = 0; i < Math.min(maxFeaturesToTry, nFeatures); i++) {
      featureIndices.push(shuffled[i]);
    }

    let bestScore = Infinity;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestLeftX: number[][] = [];
    let bestLeftY: number[] = [];
    let bestRightX: number[][] = [];
    let bestRightY: number[] = [];

    for (const fIdx of featureIndices) {
      // Pick representative candidate split thresholds
      const values = X.map((row) => row[fIdx]).sort((a, b) => a - b);
      const uniqueVals = Array.from(new Set(values));
      if (uniqueVals.length <= 1) continue;

      // Sample up to 10 split points
      const step = Math.max(1, Math.floor(uniqueVals.length / 10));
      for (let i = 0; i < uniqueVals.length - 1; i += step) {
        const threshold = (uniqueVals[i] + uniqueVals[i + 1]) / 2;

        const leftY: number[] = [];
        const rightY: number[] = [];
        const leftX: number[][] = [];
        const rightX: number[][] = [];

        for (let r = 0; r < nSamples; r++) {
          if (X[r][fIdx] <= threshold) {
            leftX.push(X[r]);
            leftY.push(y[r]);
          } else {
            rightX.push(X[r]);
            rightY.push(y[r]);
          }
        }

        if (leftY.length === 0 || rightY.length === 0) continue;

        const leftVar = this.variance(leftY);
        const rightVar = this.variance(rightY);
        const weightedScore = (leftY.length * leftVar + rightY.length * rightVar) / nSamples;

        if (weightedScore < bestScore) {
          bestScore = weightedScore;
          bestFeature = fIdx;
          bestThreshold = threshold;
          bestLeftX = leftX;
          bestLeftY = leftY;
          bestRightX = rightX;
          bestRightY = rightY;
        }
      }
    }

    if (bestFeature === -1 || bestLeftY.length === 0 || bestRightY.length === 0) {
      return { isLeaf: true, value: meanValue };
    }

    // Feature importance: reduction in variance weighted by samples
    const varianceReduction = (currentVar - bestScore) * nSamples;
    if (varianceReduction > 0) {
      this.featureImportanceAccumulator[bestFeature] += varianceReduction;
    }

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: this.buildTree(bestLeftX, bestLeftY, depth + 1),
      right: this.buildTree(bestRightX, bestRightY, depth + 1)
    };
  }

  private variance(arr: number[]): number {
    if (arr.length <= 1) return 0;
    const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
    return arr.reduce((sum, val) => sum + (val - mean) ** 2, 0) / arr.length;
  }

  predictRow(node: TreeNode | null, x: number[]): number {
    if (!node) return 0;
    if (node.isLeaf || node.featureIndex === undefined || node.threshold === undefined) {
      return node.value ?? 0;
    }
    if (x[node.featureIndex] <= node.threshold) {
      return this.predictRow(node.left ?? null, x);
    } else {
      return this.predictRow(node.right ?? null, x);
    }
  }
}

export class RandomForestRegressorModel {
  private trees: RegressionTree[] = [];
  private nTrees: number;
  private maxDepth: number;
  private minSamplesSplit: number;
  private featureNames: string[];
  private aggregatedImportance: number[] = [];

  constructor(nTrees = 16, maxDepth = 6, minSamplesSplit = 4, featureNames: string[] = []) {
    this.nTrees = nTrees;
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
    this.featureNames = featureNames;
  }

  fit(X: number[][], y: number[]): void {
    const nSamples = X.length;
    const nFeatures = X[0]?.length || 0;
    this.trees = [];
    this.aggregatedImportance = new Array(nFeatures).fill(0);

    for (let t = 0; t < this.nTrees; t++) {
      // Bootstrap sampling (bagging) with replacement
      const bootX: number[][] = [];
      const bootY: number[] = [];
      for (let i = 0; i < nSamples; i++) {
        const randomIndex = Math.floor(Math.random() * nSamples);
        bootX.push(X[randomIndex]);
        bootY.push(y[randomIndex]);
      }

      const tree = new RegressionTree(this.maxDepth, this.minSamplesSplit, nFeatures);
      tree.fit(bootX, bootY);
      this.trees.push(tree);

      // Accumulate importance
      for (let f = 0; f < nFeatures; f++) {
        this.aggregatedImportance[f] += tree.featureImportanceAccumulator[f];
      }
    }
  }

  predict(x: number[]): number {
    if (this.trees.length === 0) return 0;
    let sum = 0;
    for (const tree of this.trees) {
      sum += tree.predictRow(tree.root, x);
    }
    return Math.max(0, sum / this.trees.length);
  }

  getFeatureImportance(): FeatureImportanceItem[] {
    const total = this.aggregatedImportance.reduce((a, b) => a + b, 0) || 1;

    return this.aggregatedImportance.map((imp, idx) => {
      const percentage = Math.round((imp / total) * 1000) / 10;
      return {
        feature: this.featureNames[idx] || `Feature ${idx + 1}`,
        importance: Math.round(imp),
        percentage
      };
    }).sort((a, b) => b.importance - a.importance);
  }
}
