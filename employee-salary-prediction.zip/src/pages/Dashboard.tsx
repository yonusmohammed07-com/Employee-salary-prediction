import React, { useMemo } from 'react';
import {
  Users,
  IndianRupee,
  TrendingDown,
  TrendingUp,
  Clock,
  GraduationCap,
  Building2,
  Briefcase,
  Layers,
  ArrowRight
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  ZAxis,
  LineChart,
  Line,
  Cell
} from 'recharts';
import { CleanEmployeeRecord, TrainedModelsState } from '../types';
import { StatCard } from '../components/StatCard';
import { ChartCard } from '../components/ChartCard';
import {
  computeOverallStats,
  computeDepartmentStats,
  computeJobRoleStats,
  computeExperienceGroupStats,
  computeEducationStats,
  computePerformanceStats,
  computeSalaryDistribution,
  formatCurrency
} from '../utils/salaryAnalysis';

interface DashboardProps {
  records: CleanEmployeeRecord[];
  modelsState: TrainedModelsState;
  onNavigate: (tab: 'dashboard' | 'predictor' | 'analysis' | 'performance') => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  records,
  modelsState,
  onNavigate
}) => {
  const overall = useMemo(() => computeOverallStats(records), [records]);
  const deptStats = useMemo(() => computeDepartmentStats(records), [records]);
  const roleStats = useMemo(() => computeJobRoleStats(records).slice(0, 8), [records]);
  const expStats = useMemo(() => computeExperienceGroupStats(records), [records]);
  const eduStats = useMemo(() => computeEducationStats(records), [records]);
  const perfStats = useMemo(() => computePerformanceStats(records), [records]);
  const distStats = useMemo(() => computeSalaryDistribution(records), [records]);

  // Scatter plot data for Experience vs Salary
  const scatterExpSalary = useMemo(() => {
    return records.map((r) => ({
      experience: r.years_experience,
      salary: r.salary,
      role: r.job_role,
      education: r.education_level
    }));
  }, [records]);

  return (
    <div className="space-y-6">
      {/* Welcome & Quick Action Hero */}
      <div className="rounded-2xl border border-indigo-100 bg-gradient-to-r from-indigo-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xs sm:p-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-500/20 px-3 py-1 text-xs font-semibold text-indigo-300 backdrop-blur-xs border border-indigo-400/20">
              <Layers className="h-3.5 w-3.5" /> In-Browser Machine Learning Pipeline
            </span>
            <h2 className="mt-3 text-2xl font-bold tracking-tight text-white sm:text-3xl">
              Employee Compensation Intelligence
            </h2>
            <p className="mt-2 text-xs text-indigo-200 sm:text-sm leading-relaxed">
              Explore dynamic salary benchmarks across departments, validate regression models, and generate instantaneous compensation forecasts using machine learning.
            </p>
          </div>
          <div className="flex shrink-0 gap-2.5">
            <button
              onClick={() => onNavigate('predictor')}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-500 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-xs hover:bg-indigo-400 transition-colors"
            >
              <span>Estimate a Salary</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 8 Statistics Cards (Strictly required in Section 5) */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* 1. Total Employees */}
        <StatCard
          id="stat-total-employees"
          title="Total Employees"
          value={overall.totalEmployees}
          subtitle="Processed & validated records"
          icon={Users}
          badge="100% Validated"
          badgeType="success"
        />

        {/* 2. Average Salary */}
        <StatCard
          id="stat-avg-salary"
          title="Average Salary"
          value={formatCurrency(overall.averageSalary)}
          subtitle="Mean annual payroll"
          icon={IndianRupee}
          badge="Dynamic"
          badgeType="indigo"
        />

        {/* 3. Minimum Salary */}
        <StatCard
          id="stat-min-salary"
          title="Minimum Salary"
          value={formatCurrency(overall.minSalary)}
          subtitle="Entry-level floor"
          icon={TrendingDown}
          badge="Observed Min"
          badgeType="neutral"
        />

        {/* 4. Maximum Salary */}
        <StatCard
          id="stat-max-salary"
          title="Maximum Salary"
          value={formatCurrency(overall.maxSalary)}
          subtitle="Executive cap"
          icon={TrendingUp}
          badge="Observed Max"
          badgeType="indigo"
        />

        {/* 5. Average Experience */}
        <StatCard
          id="stat-avg-experience"
          title="Average Experience"
          value={`${overall.averageExperience} Years`}
          subtitle="Organization tenure median"
          icon={Clock}
          badge="Mid-Career Avg"
          badgeType="neutral"
        />

        {/* 6. Average Education Level */}
        <StatCard
          id="stat-education-level"
          title="Dominant Education"
          value={overall.mostCommonEducation}
          subtitle="Modal qualification attained"
          icon={GraduationCap}
          badge="Modal Cohort"
          badgeType="neutral"
        />

        {/* 7. Highest Paying Department */}
        <StatCard
          id="stat-highest-department"
          title="Top Department"
          value={overall.highestPayingDepartment.name}
          subtitle={`Avg ${formatCurrency(overall.highestPayingDepartment.avgSalary)}`}
          icon={Building2}
          badge="Rank #1 Dept"
          badgeType="success"
        />

        {/* 8. Highest Paying Job Role */}
        <StatCard
          id="stat-highest-role"
          title="Top Job Role"
          value={overall.highestPayingJobRole.name}
          subtitle={`Avg ${formatCurrency(overall.highestPayingJobRole.avgSalary)}`}
          icon={Briefcase}
          badge="Rank #1 Role"
          badgeType="indigo"
        />
      </div>

      {/* Dashboard Charts (Sections 5 & 32) */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Chart 1: Salary Distribution */}
        <ChartCard
          id="chart-salary-distribution"
          title="Annual Salary Distribution"
          subtitle="Histogram of employee counts grouped by compensation brackets"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={distStats} margin={{ top: 15, right: 10, left: -10, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis
                  dataKey="range"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} allowDecimals={false} />
                <Tooltip
                  formatter={(val: any) => [`${val} employees`, 'Count']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="count" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 2: Experience vs Salary */}
        <ChartCard
          id="chart-experience-vs-salary"
          title="Experience vs Salary Scatter"
          subtitle="Individual employee data points showing tenure trajectory"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 15, right: 15, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  dataKey="experience"
                  name="Experience"
                  unit="y"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  label={{ value: 'Years of Experience', position: 'bottom', offset: 0, fontSize: 11, fill: '#64748b' }}
                />
                <YAxis
                  type="number"
                  dataKey="salary"
                  name="Salary"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                />
                <ZAxis range={[25, 25]} />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="rounded-lg border border-slate-200 bg-white p-2.5 text-xs shadow-md">
                          <p className="font-semibold text-slate-900">{data.role}</p>
                          <p className="text-slate-500">Exp: {data.experience} yrs</p>
                          <p className="font-bold text-indigo-600">{formatCurrency(data.salary)}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter name="Employees" data={scatterExpSalary} fill="#6366f1" />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 3: Education vs Salary */}
        <ChartCard
          id="chart-education-vs-salary"
          title="Education Level vs Average Salary"
          subtitle="Compensation premiums tied to academic attainment"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={eduStats} margin={{ top: 15, right: 10, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="educationLevel" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="avgSalary" fill="#0ea5e9" radius={[4, 4, 0, 0]}>
                  {eduStats.map((_, index) => (
                    <Cell
                      key={`cell-edu-${index}`}
                      fill={['#94a3b8', '#64748b', '#0ea5e9', '#3b82f6', '#4f46e5'][index % 5]}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 4: Department-wise Average Salary */}
        <ChartCard
          id="chart-department-salary"
          title="Department-wise Average Salary"
          subtitle="Ranked average annual compensation by organizational unit"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={deptStats}
                margin={{ top: 10, right: 20, left: 50, bottom: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                />
                <YAxis
                  type="category"
                  dataKey="department"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  width={90}
                />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="avgSalary" fill="#3b82f6" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 5: Job Role-wise Average Salary */}
        <ChartCard
          id="chart-job-role-salary"
          title="Top 8 Roles by Average Compensation"
          subtitle="Highest average earnings by individual job title"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={roleStats}
                margin={{ top: 10, right: 20, left: 70, bottom: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                />
                <YAxis
                  type="category"
                  dataKey="jobRole"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  width={110}
                />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Bar dataKey="avgSalary" fill="#6366f1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Chart 6: Performance vs Salary */}
        <ChartCard
          id="chart-performance-vs-salary"
          title="Performance Score vs Average Salary"
          subtitle="Correlation between appraisal performance brackets and earnings"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={perfStats} margin={{ top: 15, right: 15, left: 10, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="range" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                />
                <Tooltip
                  formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                  contentStyle={{
                    backgroundColor: '#ffffff',
                    borderColor: '#e2e8f0',
                    borderRadius: '8px',
                    fontSize: '12px'
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="avgSalary"
                  stroke="#10b981"
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#10b981' }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>

      {/* Experience Group Comparison Table (Section 5 requirement) */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="border-b border-slate-100 pb-3 mb-4">
          <h3 className="text-base font-bold text-slate-900">
            Experience Cohort Breakdown
          </h3>
          <p className="text-xs text-slate-500">
            Distribution and progression statistics across tenure groups.
          </p>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {expStats.map((exp) => (
            <div key={exp.group} className="rounded-lg border border-slate-100 bg-slate-50 p-3.5">
              <span className="text-xs font-semibold text-indigo-700">{exp.group}</span>
              <div className="mt-1 text-base font-bold text-slate-900">
                {formatCurrency(exp.avgSalary)}
              </div>
              <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500">
                <span>{exp.count} employees</span>
                <span>Max: {formatCurrency(exp.maxSalary)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
