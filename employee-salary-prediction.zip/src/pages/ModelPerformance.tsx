import React, { useState, useMemo } from 'react';
import {
  Cpu,
  RefreshCw,
  Award,
  Layers,
  Sparkles,
  BarChart3,
  Sliders,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Line,
  Cell
} from 'recharts';
import { TrainedModelsState } from '../types';
import { ModelMetrics } from '../components/ModelMetrics';
import { ResidualChart } from '../components/ResidualChart';
import { ChartCard } from '../components/ChartCard';
import { formatCurrency } from '../utils/salaryAnalysis';

interface ModelPerformanceProps {
  modelsState: TrainedModelsState;
  onRetrain: () => void;
  isTraining: boolean;
}

export const ModelPerformance: React.FC<ModelPerformanceProps> = ({
  modelsState,
  onRetrain,
  isTraining
}) => {
  const [activeModel, setActiveModel] = useState<'Linear Regression' | 'Random Forest Regression'>(
    'Random Forest Regression'
  );

  const currentModel =
    activeModel === 'Random Forest Regression'
      ? modelsState.randomForest
      : modelsState.linear;

  const currentPredictions = currentModel?.testPredictions || [];

  // Actual vs Predicted points for scatter plot
  const actualVsPredData = useMemo(() => {
    return currentPredictions.map((p) => ({
      actual: p.actual,
      predicted: p.predicted,
      residual: p.residual
    }));
  }, [currentPredictions]);

  // Ideal line reference min & max
  const bounds = useMemo(() => {
    if (actualVsPredData.length === 0) return { min: 300000, max: 2000000 };
    const allVals = actualVsPredData.flatMap((d) => [d.actual, d.predicted]);
    return {
      min: Math.floor(Math.min(...allVals) / 100000) * 100000,
      max: Math.ceil(Math.max(...allVals) / 100000) * 100000
    };
  }, [actualVsPredData]);

  // Feature Importance data
  const featureImportance = useMemo(() => {
    return (
      modelsState.randomForest?.featureImportance ||
      modelsState.linear?.featureImportance ||
      []
    );
  }, [modelsState.randomForest, modelsState.linear]);

  return (
    <div className="space-y-6">
      {/* Header & Retrain Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between rounded-xl border border-slate-200 bg-white p-5 shadow-xs gap-3">
        <div>
          <h2 className="text-lg font-bold text-slate-900">
            Regression Model Benchmarks &amp; Diagnostics
          </h2>
          <p className="text-xs text-slate-500">
            Compare Ridge Linear Regression and Random Forest Regressor trained client-side with zero external API calls.
          </p>
        </div>

        <button
          id="btn-retrain-models"
          onClick={onRetrain}
          disabled={isTraining}
          className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-indigo-700 disabled:opacity-50 transition-colors"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${isTraining ? 'animate-spin' : ''}`} />
          <span>{isTraining ? 'Retraining Models...' : 'Retrain Pipeline'}</span>
        </button>
      </div>

      {/* Model Metrics Table (Section 26 & 29) */}
      <ModelMetrics
        linearMetrics={modelsState.linear?.metrics || null}
        rfMetrics={modelsState.randomForest?.metrics || null}
        activeModelType={activeModel}
        onSelectModel={(m) => setActiveModel(m)}
      />

      {/* Actual vs Predicted and Feature Importance Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Actual vs Predicted Scatter Chart (Section 32) */}
        <ChartCard
          id="chart-actual-vs-predicted"
          title={`Actual vs Predicted Salary (${activeModel})`}
          subtitle="Proximity to the diagonal indicates prediction accuracy"
          action={
            <div className="text-[11px] font-medium text-slate-500">
              R²: <strong className="text-indigo-600">{currentModel?.metrics.r2}</strong>
            </div>
          }
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 15, right: 15, left: 15, bottom: 25 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  dataKey="actual"
                  name="Actual"
                  domain={[bounds.min, bounds.max]}
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                  label={{ value: 'Actual Salary (Test Set)', position: 'bottom', offset: 5, fontSize: 11, fill: '#64748b' }}
                />
                <YAxis
                  type="number"
                  dataKey="predicted"
                  name="Predicted"
                  domain={[bounds.min, bounds.max]}
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                  label={{ value: 'Predicted Salary', angle: -90, position: 'left', offset: 0, fontSize: 11, fill: '#64748b' }}
                />
                <Tooltip
                  cursor={{ strokeDasharray: '3 3' }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="rounded-lg border border-slate-200 bg-white p-2.5 text-xs shadow-md">
                          <p className="text-slate-500">Actual: {formatCurrency(data.actual)}</p>
                          <p className="font-bold text-indigo-600">
                            Predicted: {formatCurrency(data.predicted)}
                          </p>
                          <p className="text-[11px] text-slate-400">
                            Residual: {formatCurrency(data.residual)}
                          </p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter name="Predictions" data={actualVsPredData} fill="#4f46e5" opacity={0.8} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>

        {/* Feature Importance Bar Chart (Section 31) */}
        <ChartCard
          id="chart-feature-importance"
          title="Feature Importance Ranking"
          subtitle="Relative contribution of predictive signals in the model"
        >
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                layout="vertical"
                data={featureImportance}
                margin={{ top: 10, right: 20, left: 60, bottom: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis
                  type="number"
                  domain={[0, 100]}
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  tickFormatter={(val) => `${val}%`}
                />
                <YAxis
                  type="category"
                  dataKey="feature"
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  width={100}
                />
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Relative Importance']}
                  contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="importance" fill="#6366f1" radius={[0, 4, 4, 0]}>
                  {featureImportance.map((_, index) => (
                    <Cell
                      key={`cell-feat-${index}`}
                      fill={['#4f46e5', '#6366f1', '#818cf8', '#a5b4fc', '#c7d2fe', '#e0e7ff'][index % 6]}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </ChartCard>
      </div>

      {/* Residual Diagnostics (Section 28) */}
      <ResidualChart
        testPredictions={currentPredictions}
        modelName={activeModel}
      />
    </div>
  );
};
