import React, { useMemo, useState } from 'react';
import {
  Users,
  IndianRupee,
  Layers,
  GraduationCap,
  Briefcase,
  Building,
  Target,
  Sparkles,
  BarChart2
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line
} from 'recharts';
import { CleanEmployeeRecord } from '../types';
import { EmployeeTable } from '../components/EmployeeTable';
import { ChartCard } from '../components/ChartCard';
import {
  computeOverallStats,
  computeDepartmentStats,
  computeJobRoleStats,
  computeExperienceGroupStats,
  computeEducationStats,
  computePerformanceStats,
  formatCurrency
} from '../utils/salaryAnalysis';

interface SalaryAnalysisProps {
  records: CleanEmployeeRecord[];
  departments: string[];
  jobRoles: string[];
  educationLevels: string[];
}

export const SalaryAnalysis: React.FC<SalaryAnalysisProps> = ({
  records,
  departments,
  jobRoles,
  educationLevels
}) => {
  const [activeAnalysisTab, setActiveAnalysisTab] = useState<
    'experience' | 'education' | 'department' | 'role' | 'performance'
  >('experience');

  const overall = useMemo(() => computeOverallStats(records), [records]);
  const expStats = useMemo(() => computeExperienceGroupStats(records), [records]);
  const eduStats = useMemo(() => computeEducationStats(records), [records]);
  const deptStats = useMemo(() => computeDepartmentStats(records), [records]);
  const roleStats = useMemo(() => computeJobRoleStats(records), [records]);
  const perfStats = useMemo(() => computePerformanceStats(records), [records]);

  return (
    <div className="space-y-6">
      {/* 7 Key Analytics Metrics (Section 18 requirement) */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Total Employees
          </span>
          <div className="mt-1 text-xl font-bold text-slate-900">{overall.totalEmployees}</div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Average Salary
          </span>
          <div className="mt-1 text-xl font-bold text-indigo-600">
            {formatCurrency(overall.averageSalary)}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Median Salary
          </span>
          <div className="mt-1 text-xl font-bold text-slate-900">
            {formatCurrency(overall.medianSalary)}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Minimum Salary
          </span>
          <div className="mt-1 text-xl font-bold text-slate-700">
            {formatCurrency(overall.minSalary)}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Maximum Salary
          </span>
          <div className="mt-1 text-xl font-bold text-slate-900">
            {formatCurrency(overall.maxSalary)}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Avg Experience
          </span>
          <div className="mt-1 text-xl font-bold text-slate-900">
            {overall.averageExperience} yrs
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-xs">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">
            Avg Performance
          </span>
          <div className="mt-1 text-xl font-bold text-emerald-600">
            {overall.averagePerformanceScore}/100
          </div>
        </div>
      </div>

      {/* Category Deep-Dive Selector */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-100 pb-4 mb-4 gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Dimensional Compensation Analysis
            </h3>
            <p className="text-xs text-slate-500">
              Examine salary distribution segmented by key professional and organizational dimensions.
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5 rounded-lg border border-slate-200 bg-slate-50 p-1">
            <button
              onClick={() => setActiveAnalysisTab('experience')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                activeAnalysisTab === 'experience'
                  ? 'bg-white text-indigo-600 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Experience (Tenure)
            </button>
            <button
              onClick={() => setActiveAnalysisTab('education')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                activeAnalysisTab === 'education'
                  ? 'bg-white text-indigo-600 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Education
            </button>
            <button
              onClick={() => setActiveAnalysisTab('department')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                activeAnalysisTab === 'department'
                  ? 'bg-white text-indigo-600 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Department
            </button>
            <button
              onClick={() => setActiveAnalysisTab('role')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                activeAnalysisTab === 'role'
                  ? 'bg-white text-indigo-600 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Job Roles
            </button>
            <button
              onClick={() => setActiveAnalysisTab('performance')}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-all ${
                activeAnalysisTab === 'performance'
                  ? 'bg-white text-indigo-600 shadow-xs font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Performance
            </button>
          </div>
        </div>

        {/* Tab 1: Experience Analysis (Section 21) */}
        {activeAnalysisTab === 'experience' && (
          <div className="space-y-4">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={expStats} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="group" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis
                    tick={{ fontSize: 10, fill: '#64748b' }}
                    tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                  />
                  <Tooltip
                    formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Bar dataKey="avgSalary" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-semibold">
                    <th className="px-4 py-2.5">Experience Group</th>
                    <th className="px-4 py-2.5">Employee Count</th>
                    <th className="px-4 py-2.5">Average Salary</th>
                    <th className="px-4 py-2.5">Minimum Salary</th>
                    <th className="px-4 py-2.5">Maximum Salary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {expStats.map((exp) => (
                    <tr key={exp.group} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 font-semibold text-slate-900">{exp.group}</td>
                      <td className="px-4 py-2.5 text-slate-600">{exp.count} employees</td>
                      <td className="px-4 py-2.5 font-bold text-indigo-600">{formatCurrency(exp.avgSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(exp.minSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-900 font-semibold">{formatCurrency(exp.maxSalary)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Education Analysis (Section 22) */}
        {activeAnalysisTab === 'education' && (
          <div className="space-y-4">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={eduStats} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="educationLevel" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis
                    tick={{ fontSize: 10, fill: '#64748b' }}
                    tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                  />
                  <Tooltip
                    formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Bar dataKey="avgSalary" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-semibold">
                    <th className="px-4 py-2.5">Education Level</th>
                    <th className="px-4 py-2.5">Employee Count</th>
                    <th className="px-4 py-2.5">Average Salary</th>
                    <th className="px-4 py-2.5">Median Salary</th>
                    <th className="px-4 py-2.5">Observed Range</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {eduStats.map((edu) => (
                    <tr key={edu.educationLevel} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 font-semibold text-slate-900">{edu.educationLevel}</td>
                      <td className="px-4 py-2.5 text-slate-600">{edu.count} employees</td>
                      <td className="px-4 py-2.5 font-bold text-indigo-600">{formatCurrency(edu.avgSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(edu.medianSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-700">
                        {formatCurrency(edu.minSalary)} – {formatCurrency(edu.maxSalary)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Department Analysis (Section 23) */}
        {activeAnalysisTab === 'department' && (
          <div className="space-y-4">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={deptStats} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="department" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis
                    tick={{ fontSize: 10, fill: '#64748b' }}
                    tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                  />
                  <Tooltip
                    formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Bar dataKey="avgSalary" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-semibold">
                    <th className="px-4 py-2.5">Department</th>
                    <th className="px-4 py-2.5">Employee Count</th>
                    <th className="px-4 py-2.5">Average Salary</th>
                    <th className="px-4 py-2.5">Median Salary</th>
                    <th className="px-4 py-2.5">Highest Salary</th>
                    <th className="px-4 py-2.5">Lowest Salary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {deptStats.map((d) => (
                    <tr key={d.department} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 font-semibold text-slate-900">{d.department}</td>
                      <td className="px-4 py-2.5 text-slate-600">{d.count} employees</td>
                      <td className="px-4 py-2.5 font-bold text-indigo-600">{formatCurrency(d.avgSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(d.medianSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-900 font-semibold">{formatCurrency(d.maxSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(d.minSalary)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 4: Job Role Analysis (Section 24) */}
        {activeAnalysisTab === 'role' && (
          <div className="space-y-4">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-semibold">
                    <th className="px-4 py-2.5">Job Role</th>
                    <th className="px-4 py-2.5">Department</th>
                    <th className="px-4 py-2.5">Employee Count</th>
                    <th className="px-4 py-2.5">Average Salary</th>
                    <th className="px-4 py-2.5">Median Salary</th>
                    <th className="px-4 py-2.5">Salary Range</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {roleStats.slice(0, 15).map((r) => (
                    <tr key={r.jobRole} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 font-semibold text-slate-900">{r.jobRole}</td>
                      <td className="px-4 py-2.5 text-slate-600">{r.department}</td>
                      <td className="px-4 py-2.5 text-slate-600">{r.count}</td>
                      <td className="px-4 py-2.5 font-bold text-indigo-600">{formatCurrency(r.avgSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-600">{formatCurrency(r.medianSalary)}</td>
                      <td className="px-4 py-2.5 text-slate-700">
                        {formatCurrency(r.minSalary)} – {formatCurrency(r.maxSalary)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 5: Performance Analysis (Section 25) */}
        {activeAnalysisTab === 'performance' && (
          <div className="space-y-4">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={perfStats} margin={{ top: 10, right: 10, left: 10, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="range" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis
                    tick={{ fontSize: 10, fill: '#64748b' }}
                    tickFormatter={(val) => `₹${(val / 100000).toFixed(0)}L`}
                  />
                  <Tooltip
                    formatter={(val: any) => [formatCurrency(val), 'Average Salary']}
                    contentStyle={{ backgroundColor: '#ffffff', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="avgSalary"
                    stroke="#10b981"
                    strokeWidth={2.5}
                    dot={{ r: 4, fill: '#10b981' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-slate-700 font-semibold">
                    <th className="px-4 py-2.5">Performance Score Group</th>
                    <th className="px-4 py-2.5">Employee Count</th>
                    <th className="px-4 py-2.5">Average Salary</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {perfStats.map((p) => (
                    <tr key={p.range} className="hover:bg-slate-50">
                      <td className="px-4 py-2.5 font-semibold text-slate-900">{p.range}</td>
                      <td className="px-4 py-2.5 text-slate-600">{p.count} employees</td>
                      <td className="px-4 py-2.5 font-bold text-emerald-600">{formatCurrency(p.avgSalary)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="rounded-lg bg-slate-50 p-3 text-xs text-slate-500">
              Note: Findings reflect historical compensation distributions and correlations across the dataset. Statistical associations do not establish singular causal determinants.
            </div>
          </div>
        )}
      </div>

      {/* Employee Explorer Table (Section 19) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Employee Directory Explorer
            </h3>
            <p className="text-xs text-slate-500">
              Filter, search, sort, and inspect individual verified employee records.
            </p>
          </div>
        </div>
        <EmployeeTable
          records={records}
          departments={departments}
          jobRoles={jobRoles}
          educationLevels={educationLevels}
        />
      </div>
    </div>
  );
};
