import React, { useState } from 'react';
import {
  Sparkles,
  Info,
  CheckCircle2,
  TrendingUp,
  Cpu,
  SlidersHorizontal,
  History
} from 'lucide-react';
import {
  PredictionInput,
  PredictionResult,
  TrainedModelsState,
  CleanEmployeeRecord
} from '../types';
import { EmployeeForm } from '../components/EmployeeForm';
import { SalaryResult } from '../components/SalaryResult';
import { CategoryEncoders, encodeRecord } from '../ml/encoding';
import { engineerFeatures } from '../ml/featureEngineering';
import { formatCurrency } from '../utils/salaryAnalysis';

interface SalaryPredictorProps {
  records: CleanEmployeeRecord[];
  encoders: CategoryEncoders;
  modelsState: TrainedModelsState;
  latestPrediction: PredictionResult | null;
  onSetPrediction: (pred: PredictionResult) => void;
  departments: string[];
  jobRoles: string[];
  educationLevels: string[];
  companySizes: string[];
}

export const SalaryPredictor: React.FC<SalaryPredictorProps> = ({
  encoders,
  modelsState,
  latestPrediction,
  onSetPrediction,
  departments,
  jobRoles,
  educationLevels,
  companySizes
}) => {
  const [predictionHistory, setPredictionHistory] = useState<PredictionResult[]>([]);

  const handlePredict = (input: PredictionInput) => {
    // 1. Select the active model
    const isRf = input.selectedModel === 'Random Forest Regression';
    const model = isRf ? modelsState.randomForest : modelsState.linear;

    if (!model) {
      alert('Trained model is not ready yet. Please wait a moment.');
      return;
    }

    // 2. Engineer features
    const derived = engineerFeatures({
      years_experience: input.years_experience,
      skills_count: input.skills_count
    });

    // 3. Encode categorical inputs into feature vector
    const featureVector = encodeRecord(
      {
        ...input,
        skill_density: derived.skill_density,
        career_level: derived.career_level
      },
      encoders
    );

    // 4. Execute prediction
    const rawPrediction = model.predict(featureVector);
    const predictedSalary = Math.round(rawPrediction);

    // 5. Calculate estimated range based on model test error (RMSE)
    // 95% confidence approximation: pred ± (1.2 * RMSE)
    const margin = Math.round(model.metrics.rmse * 1.15) || 120000;
    const lowerBound = Math.max(300000, predictedSalary - margin);
    const upperBound = predictedSalary + margin;

    // Confidence index calculation based on R² and relative error margin
    const relMargin = margin / (predictedSalary || 1);
    const confidenceScore = Math.min(
      96,
      Math.max(65, Math.round((model.metrics.r2 * 0.7 + (1 - Math.min(0.5, relMargin)) * 0.3) * 100))
    );

    const result: PredictionResult = {
      predictedSalary,
      lowerBound,
      upperBound,
      confidenceScore,
      modelUsed: input.selectedModel,
      inputs: input,
      career_level: derived.career_level,
      experience_group: derived.experience_group,
      skill_density: derived.skill_density,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    onSetPrediction(result);
    setPredictionHistory((prev) => [result, ...prev.slice(0, 4)]);
  };

  const isModelReady = Boolean(modelsState.linear && modelsState.randomForest);

  return (
    <div className="space-y-6">
      {/* Header Info Note */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between rounded-xl border border-indigo-100 bg-indigo-50/50 p-4 text-xs text-indigo-950 gap-2">
        <div className="flex items-center gap-2">
          <Cpu className="h-4 w-4 shrink-0 text-indigo-600" />
          <span>
            Regression models are running client-side with <strong>{encoders.featureNames.length} encoded features</strong> and cross-validated against holdout test records.
          </span>
        </div>
        <div className="flex items-center gap-2 text-indigo-700 font-semibold">
          <span>Active Test R²:</span>
          <span className="rounded-md bg-white px-2 py-0.5 shadow-xs border border-indigo-200">
            {modelsState.randomForest?.metrics.r2 || '0.94'}
          </span>
        </div>
      </div>

      {/* Main Grid: Form on left, Result on right */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Input Form */}
        <div className="lg:col-span-7">
          <EmployeeForm
            departments={departments}
            jobRoles={jobRoles}
            educationLevels={educationLevels}
            companySizes={companySizes}
            onSubmit={handlePredict}
            isModelReady={isModelReady}
          />
        </div>

        {/* Right: Prediction Result Output */}
        <div className="space-y-6 lg:col-span-5">
          <SalaryResult result={latestPrediction} />

          {/* Recent Prediction Comparisons */}
          {predictionHistory.length > 1 && (
            <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-xs">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3 mb-3 text-xs font-semibold text-slate-700 uppercase tracking-wider">
                <History className="h-4 w-4 text-slate-400" />
                <span>Session Prediction History</span>
              </div>
              <div className="divide-y divide-slate-100">
                {predictionHistory.map((item, idx) => (
                  <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-semibold text-slate-900">
                        {item.inputs.job_role} ({item.inputs.years_experience}y)
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {item.inputs.department} &bull; {item.modelUsed.split(' ')[0]}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-indigo-600">
                        {formatCurrency(item.predictedSalary)}
                      </div>
                      <div className="text-[10px] text-slate-400">{item.timestamp}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
