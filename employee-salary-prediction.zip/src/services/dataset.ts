import Papa from 'papaparse';
import { RawEmployeeRecord } from '../types';
import { preprocessDataset, PreprocessingResult } from '../ml/preprocessing';

export async function fetchDefaultDataset(): Promise<PreprocessingResult> {
  const response = await fetch('/data/employee_salaries.csv');
  if (!response.ok) {
    throw new Error(`Failed to load employee_salaries.csv (HTTP status ${response.status})`);
  }

  const csvText = await response.text();
  return parseCsvString(csvText);
}

export function parseCsvString(csvContent: string): Promise<PreprocessingResult> {
  return new Promise((resolve, reject) => {
    Papa.parse<RawEmployeeRecord>(csvContent, {
      header: true,
      skipEmptyLines: true,
      dynamicTyping: true,
      complete: (results) => {
        try {
          if (!results.data || results.data.length === 0) {
            resolve({
              validRecords: [],
              discardedCount: 0,
              departments: [],
              jobRoles: [],
              educationLevels: [],
              companySizes: [],
              error: 'The provided CSV file contains no data rows.'
            });
            return;
          }

          const processed = preprocessDataset(results.data);
          resolve(processed);
        } catch (err: any) {
          reject(new Error(`Data preprocessing error: ${err.message || err}`));
        }
      },
      error: (error: any) => {
        reject(new Error(`CSV Parsing failed: ${error.message}`));
      }
    });
  });
}
