export interface RawEmployeeRecord {
  employee_id?: string;
  age?: string | number;
  gender?: string;
  years_experience?: string | number;
  education_level?: string;
  job_role?: string;
  department?: string;
  skills_count?: string | number;
  certifications?: string | number;
  company_size?: string;
  performance_score?: string | number;
  salary?: string | number;
  [key: string]: any;
}

export interface CleanEmployeeRecord {
  employee_id: string;
  age: number;
  gender: string;
  years_experience: number;
  education_level: "High School" | "Diploma" | "Bachelor's" | "Master's" | "Doctorate" | string;
  job_role: string;
  department: string;
  skills_count: number;
  certifications: number;
  company_size: "Small" | "Medium" | "Large" | string;
  performance_score: number;
  salary: number;
  // Feature engineered fields
  experience_group: "0–2 years" | "3–5 years" | "6–10 years" | "11–15 years" | "16+ years";
  career_level: "Entry" | "Junior" | "Mid" | "Senior" | "Expert";
  skill_density: number;
}

export interface ModelMetrics {
  mae: number;
  mse: number;
  rmse: number;
  r2: number;
}

export interface PredictionPoint {
  id: string;
  actual: number;
  predicted: number;
  residual: number;
  role: string;
  dept: string;
}

export interface FeatureImportanceItem {
  feature: string;
  importance: number;
  percentage: number;
}

export interface TrainedModelResult {
  modelType: "Linear Regression" | "Random Forest Regression";
  metrics: ModelMetrics;
  testPredictions: PredictionPoint[];
  featureImportance: FeatureImportanceItem[];
  predict: (features: number[]) => number;
}

export interface TrainedModelsState {
  linear: TrainedModelResult | null;
  randomForest: TrainedModelResult | null;
  featureNames: string[];
  trainCount: number;
  testCount: number;
  isTraining: boolean;
  trainingProgress: number;
  error: string | null;
}

export interface PredictionInput {
  age: number;
  years_experience: number;
  education_level: string;
  job_role: string;
  department: string;
  skills_count: number;
  certifications: number;
  company_size: string;
  performance_score: number;
  selectedModel: "Linear Regression" | "Random Forest Regression";
}

export interface PredictionResult {
  predictedSalary: number;
  lowerBound: number;
  upperBound: number;
  confidenceScore: number;
  modelUsed: "Linear Regression" | "Random Forest Regression";
  inputs: PredictionInput;
  career_level: string;
  experience_group: string;
  skill_density: number;
  timestamp: string;
}

export interface SalaryInsights {
  averageSalary: number;
  medianSalary: number;
  minSalary: number;
  maxSalary: number;
  highestPayingDepartment: { name: string; avgSalary: number };
  highestPayingRole: { name: string; avgSalary: number };
  highestPayingExpGroup: { group: string; avgSalary: number };
  highestPayingEducation: { level: string; avgSalary: number };
  performanceRelationship: string;
  bestModelName: string;
  modelR2: number;
  modelRmse: number;
  topInfluentialFactors: string[];
}
