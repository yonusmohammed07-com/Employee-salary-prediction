import { FeatureImportanceItem } from '../types';

export function normalizeFeatureImportance(
  rawList: { feature: string; importance: number }[]
): FeatureImportanceItem[] {
  const total = rawList.reduce((acc, curr) => acc + Math.abs(curr.importance), 0) || 1;
  return rawList.map((item) => ({
    feature: item.feature,
    importance: Math.round(item.importance),
    percentage: Math.round((Math.abs(item.importance) / total) * 1000) / 10
  })).sort((a, b) => b.importance - a.importance);
}
