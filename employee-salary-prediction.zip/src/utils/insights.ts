import { CleanEmployeeRecord, TrainedModelsState, SalaryInsights } from '../types';
import {
  computeOverallStats,
  computeDepartmentStats,
  computeJobRoleStats,
  computeExperienceGroupStats,
  computeEducationStats,
  computePerformanceStats,
  formatCurrency
} from './salaryAnalysis';

export function generateSalaryInsights(
  records: CleanEmployeeRecord[],
  modelsState: TrainedModelsState
): SalaryInsights {
  const overall = computeOverallStats(records);
  const deptStats = computeDepartmentStats(records);
  const roleStats = computeJobRoleStats(records);
  const expStats = computeExperienceGroupStats(records);
  const eduStats = computeEducationStats(records);
  const perfStats = computePerformanceStats(records);

  const highestDept = deptStats[0]
    ? { name: deptStats[0].department, avgSalary: deptStats[0].avgSalary }
    : overall.highestPayingDepartment;

  const highestRole = roleStats[0]
    ? { name: roleStats[0].jobRole, avgSalary: roleStats[0].avgSalary }
    : overall.highestPayingJobRole;

  const sortedExp = [...expStats].sort((a, b) => b.avgSalary - a.avgSalary);
  const highestExpGroup = sortedExp[0]
    ? { group: sortedExp[0].group, avgSalary: sortedExp[0].avgSalary }
    : { group: '16+ years', avgSalary: 0 };

  const sortedEdu = [...eduStats].sort((a, b) => b.avgSalary - a.avgSalary);
  const highestEdu = sortedEdu[0]
    ? { level: sortedEdu[0].educationLevel, avgSalary: sortedEdu[0].avgSalary }
    : { level: "Doctorate", avgSalary: 0 };

  // Performance relationship
  const highPerf = perfStats.find((p) => p.range === '91–100')?.avgSalary || 0;
  const lowPerf = perfStats.find((p) => p.range === '0–50')?.avgSalary || 0;
  let performanceRelationship = 'Performance scores exhibit positive salary correlation.';
  if (highPerf > 0 && lowPerf > 0) {
    const diffPct = Math.round(((highPerf - lowPerf) / lowPerf) * 100);
    performanceRelationship = `Top performers (91–100) average ${diffPct}% higher compensation (${formatCurrency(
      highPerf
    )}) compared to bottom tier (${formatCurrency(lowPerf)}).`;
  }

  // Model comparison
  const linearR2 = modelsState.linear?.metrics.r2 || 0;
  const rfR2 = modelsState.randomForest?.metrics.r2 || 0;
  const bestModelName =
    rfR2 >= linearR2 ? 'Random Forest Regression' : 'Linear Regression';
  const bestModel =
    bestModelName === 'Random Forest Regression'
      ? modelsState.randomForest
      : modelsState.linear;

  const topInfluentialFactors =
    bestModel?.featureImportance.slice(0, 3).map((f) => `${f.feature} (${f.percentage}%)`) || [
      'Years of Experience',
      'Education Level',
      'Department'
    ];

  return {
    averageSalary: overall.averageSalary,
    medianSalary: overall.medianSalary,
    minSalary: overall.minSalary,
    maxSalary: overall.maxSalary,
    highestPayingDepartment: highestDept,
    highestPayingRole: highestRole,
    highestPayingExpGroup: highestExpGroup,
    highestPayingEducation: highestEdu,
    performanceRelationship,
    bestModelName,
    modelR2: bestModel?.metrics.r2 || 0,
    modelRmse: bestModel?.metrics.rmse || 0,
    topInfluentialFactors
  };
}
