import { ModelMetrics } from '../types';

export function calculateRegressionMetrics(actuals: number[], predicteds: number[]): ModelMetrics {
  const n = actuals.length;
  if (n === 0) {
    return { mae: 0, mse: 0, rmse: 0, r2: 0 };
  }

  let absErrorSum = 0;
  let sqErrorSum = 0;
  const actualMean = actuals.reduce((a, b) => a + b, 0) / n;
  let totalSumSquares = 0;

  for (let i = 0; i < n; i++) {
    const act = actuals[i];
    const pred = predicteds[i];
    const err = act - pred;
    absErrorSum += Math.abs(err);
    sqErrorSum += err * err;
    totalSumSquares += (act - actualMean) ** 2;
  }

  const mae = Math.round(absErrorSum / n);
  const mse = Math.round(sqErrorSum / n);
  const rmse = Math.round(Math.sqrt(mse));
  const r2 = totalSumSquares > 0 ? 1 - sqErrorSum / totalSumSquares : 0;

  return {
    mae,
    mse,
    rmse,
    r2: Math.max(0, Math.min(1, Math.round(r2 * 1000) / 1000))
  };
}

export interface ResidualAnalysisResult {
  averageResidual: number;
  positiveCount: number; // actual > predicted (underestimate)
  negativeCount: number; // actual < predicted (overestimate)
  zeroCount: number;
  biasTendency: 'Underestimates slightly' | 'Overestimates slightly' | 'Balanced';
  distribution: { bin: string; count: number }[];
}

export function analyzeResiduals(residuals: number[]): ResidualAnalysisResult {
  if (residuals.length === 0) {
    return {
      averageResidual: 0,
      positiveCount: 0,
      negativeCount: 0,
      zeroCount: 0,
      biasTendency: 'Balanced',
      distribution: []
    };
  }

  const sum = residuals.reduce((a, b) => a + b, 0);
  const avg = Math.round(sum / residuals.length);

  let pos = 0;
  let neg = 0;
  let zero = 0;

  for (const r of residuals) {
    if (r > 1000) pos++;
    else if (r < -1000) neg++;
    else zero++;
  }

  let biasTendency: 'Underestimates slightly' | 'Overestimates slightly' | 'Balanced' = 'Balanced';
  if (avg > 15000) {
    biasTendency = 'Underestimates slightly';
  } else if (avg < -15000) {
    biasTendency = 'Overestimates slightly';
  }

  // Create 7 bins for residual distribution histogram
  const min = Math.min(...residuals);
  const max = Math.max(...residuals);
  const range = max - min || 1;
  const numBins = 7;
  const binWidth = range / numBins;

  const binCounts = new Array(numBins).fill(0);
  const binLabels: string[] = [];

  for (let b = 0; b < numBins; b++) {
    const low = Math.round((min + b * binWidth) / 1000);
    const high = Math.round((min + (b + 1) * binWidth) / 1000);
    binLabels.push(`${low}k to ${high}k`);
  }

  for (const r of residuals) {
    let b = Math.floor((r - min) / binWidth);
    if (b >= numBins) b = numBins - 1;
    if (b < 0) b = 0;
    binCounts[b]++;
  }

  const distribution = binLabels.map((bin, i) => ({
    bin,
    count: binCounts[i]
  }));

  return {
    averageResidual: avg,
    positiveCount: pos,
    negativeCount: neg,
    zeroCount: zero,
    biasTendency,
    distribution
  };
}
