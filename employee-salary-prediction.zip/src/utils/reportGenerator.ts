import jsPDF from 'jspdf';
import { CleanEmployeeRecord, PredictionResult, TrainedModelsState, SalaryInsights } from '../types';
import { computeOverallStats, formatCurrency } from './salaryAnalysis';

export interface GenerateReportParams {
  records: CleanEmployeeRecord[];
  modelsState: TrainedModelsState;
  latestPrediction: PredictionResult | null;
  insights: SalaryInsights;
}

export async function generatePdfReport({
  records,
  modelsState,
  latestPrediction,
  insights
}: GenerateReportParams): Promise<void> {
  if (!modelsState.linear && !modelsState.randomForest) {
    throw new Error('Train the model before generating the report.');
  }

  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'pt',
      format: 'a4'
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 40;
    let y = margin;

    // Helper function for adding headers
    const addSectionHeader = (title: string) => {
      if (y > pageHeight - 80) {
        doc.addPage();
        y = margin;
      }
      doc.setFillColor(243, 244, 246);
      doc.rect(margin, y, pageWidth - 2 * margin, 24, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(12);
      doc.setTextColor(31, 41, 55);
      doc.text(title, margin + 8, y + 16);
      y += 32;
    };

    // Header banner
    doc.setFillColor(30, 41, 59); // slate-800
    doc.rect(0, 0, pageWidth, 70, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.setTextColor(255, 255, 255);
    doc.text('Employee Salary Prediction Report', margin, 40);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9);
    doc.setTextColor(203, 213, 225);
    const dateStr = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    doc.text(`Generated: ${dateStr}   |   Dataset: employee_salaries.csv   |   Models: Linear & Random Forest`, margin, 56);

    y = 90;

    // 1. Dataset Summary
    addSectionHeader('1. Executive Dataset Summary');
    const overall = computeOverallStats(records);

    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(55, 65, 81);

    const col1X = margin + 10;
    const col2X = margin + 260;

    doc.text(`• Total Employees Analyzed: ${overall.totalEmployees}`, col1X, y);
    doc.text(`• Average Annual Salary: ${formatCurrency(overall.averageSalary)}`, col2X, y);
    y += 16;
    doc.text(`• Median Annual Salary: ${formatCurrency(overall.medianSalary)}`, col1X, y);
    doc.text(`• Salary Range: ${formatCurrency(overall.minSalary)} – ${formatCurrency(overall.maxSalary)}`, col2X, y);
    y += 16;
    doc.text(`• Average Years of Experience: ${overall.averageExperience} yrs`, col1X, y);
    doc.text(`• Average Performance Score: ${overall.averagePerformanceScore}/100`, col2X, y);
    y += 16;
    doc.text(`• Highest-Paying Dept: ${overall.highestPayingDepartment.name} (${formatCurrency(overall.highestPayingDepartment.avgSalary)})`, col1X, y);
    doc.text(`• Highest-Paying Role: ${overall.highestPayingJobRole.name} (${formatCurrency(overall.highestPayingJobRole.avgSalary)})`, col2X, y);
    y += 24;

    // 2. Prediction Section (if available)
    if (latestPrediction) {
      addSectionHeader('2. Individual Salary Prediction Record');
      doc.setFillColor(248, 250, 252);
      doc.setDrawColor(226, 232, 240);
      doc.roundedRect(margin, y, pageWidth - 2 * margin, 85, 4, 4, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.setTextColor(15, 23, 42);
      doc.text(`Estimated Annual Salary: ${formatCurrency(latestPrediction.predictedSalary)}`, col1X, y + 18);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(71, 85, 105);
      doc.text(
        `Expected 95% Confidence Range: ${formatCurrency(latestPrediction.lowerBound)} – ${formatCurrency(
          latestPrediction.upperBound
        )} (Model Confidence: ${latestPrediction.confidenceScore}%)`,
        col1X,
        y + 32
      );

      doc.text(
        `Inputs: Age ${latestPrediction.inputs.age}y | ${latestPrediction.inputs.years_experience}y Experience | ${latestPrediction.inputs.education_level} | ${latestPrediction.inputs.job_role}`,
        col1X,
        y + 50
      );
      doc.text(
        `Dept: ${latestPrediction.inputs.department} | ${latestPrediction.inputs.company_size} Firm | Perf: ${latestPrediction.inputs.performance_score}/100 | Model: ${latestPrediction.modelUsed}`,
        col1X,
        y + 64
      );
      doc.text(
        `Derived Profile: Level: ${latestPrediction.career_level} | Group: ${latestPrediction.experience_group} | Skill Density: ${latestPrediction.skill_density}`,
        col1X,
        y + 78
      );
      y += 98;
    }

    // 3. Regression Model Performance & Comparison
    addSectionHeader('3. Machine Learning Model Evaluation (80/20 Test Split)');
    const lrMetrics = modelsState.linear?.metrics;
    const rfMetrics = modelsState.randomForest?.metrics;

    // Draw table header
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, pageWidth - 2 * margin, 18, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);

    const mColMetric = margin + 10;
    const mColLR = margin + 160;
    const mColRF = margin + 310;
    const mColWinner = margin + 440;

    doc.text('Evaluation Metric', mColMetric, y + 12);
    doc.text('Linear Regression', mColLR, y + 12);
    doc.text('Random Forest', mColRF, y + 12);
    doc.text('Optimal Model', mColWinner, y + 12);
    y += 22;

    doc.setFont('helvetica', 'normal');
    const tableRows = [
      {
        metric: 'Mean Absolute Error (MAE)',
        lr: lrMetrics ? formatCurrency(lrMetrics.mae) : 'N/A',
        rf: rfMetrics ? formatCurrency(rfMetrics.mae) : 'N/A',
        better: (rfMetrics?.mae || 0) <= (lrMetrics?.mae || 0) ? 'Random Forest' : 'Linear Reg.'
      },
      {
        metric: 'Root Mean Squared Error (RMSE)',
        lr: lrMetrics ? formatCurrency(lrMetrics.rmse) : 'N/A',
        rf: rfMetrics ? formatCurrency(rfMetrics.rmse) : 'N/A',
        better: (rfMetrics?.rmse || 0) <= (lrMetrics?.rmse || 0) ? 'Random Forest' : 'Linear Reg.'
      },
      {
        metric: 'Coefficient of Determination (R²)',
        lr: lrMetrics ? `${lrMetrics.r2}` : 'N/A',
        rf: rfMetrics ? `${rfMetrics.r2}` : 'N/A',
        better: (rfMetrics?.r2 || 0) >= (lrMetrics?.r2 || 0) ? 'Random Forest' : 'Linear Reg.'
      }
    ];

    tableRows.forEach((row) => {
      doc.text(row.metric, mColMetric, y);
      doc.text(row.lr, mColLR, y);
      doc.text(row.rf, mColRF, y);
      doc.setFont('helvetica', 'bold');
      doc.text(row.better, mColWinner, y);
      doc.setFont('helvetica', 'normal');
      y += 16;
    });
    y += 12;

    // 4. Feature Importance
    addSectionHeader('4. Feature Importance & Influence Analysis');
    const activeModel = modelsState.randomForest || modelsState.linear;
    const topFeats = activeModel?.featureImportance.slice(0, 5) || [];

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.text('Ranked relative feature contribution towards salary variation:', col1X, y);
    y += 16;

    topFeats.forEach((f, idx) => {
      const barWidth = Math.min(200, (f.percentage / 100) * 250);
      doc.text(`${idx + 1}. ${f.feature}: ${f.percentage}%`, col1X, y);
      doc.setFillColor(59, 130, 246);
      doc.rect(col1X + 160, y - 8, barWidth, 7, 'F');
      y += 14;
    });
    y += 16;

    // 5. Dynamic Key Insights
    addSectionHeader('5. Strategic Salary Insights & Observations');
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    const insightLines = [
      `• Premium Department: ${insights.highestPayingDepartment.name} leads compensation with an average of ${formatCurrency(insights.highestPayingDepartment.avgSalary)}.`,
      `• Highest Earning Role: ${insights.highestPayingRole.name} records average compensation of ${formatCurrency(insights.highestPayingRole.avgSalary)}.`,
      `• Experience Trajectory: Experience bracket '${insights.highestPayingExpGroup.group}' reaches peak average earnings of ${formatCurrency(insights.highestPayingExpGroup.avgSalary)}.`,
      `• Educational Attainment: '${insights.highestPayingEducation.level}' holders command top tier salary at ${formatCurrency(insights.highestPayingEducation.avgSalary)}.`,
      `• Performance Dynamic: ${insights.performanceRelationship}`,
      `• Predictive Fidelity: ${insights.bestModelName} achieved R² of ${insights.modelR2} with testing RMSE of ${formatCurrency(insights.modelRmse)}.`
    ];

    insightLines.forEach((line) => {
      if (y > pageHeight - 40) {
        doc.addPage();
        y = margin;
      }
      doc.text(line, col1X, y);
      y += 16;
    });

    // Footer note
    y += 12;
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(
      'Notice: Salary estimates are generated through browser-side supervised regression models trained on historical employee records and represent statistical approximations, not guaranteed contracts.',
      margin,
      pageHeight - 20
    );

    // Save and trigger download
    doc.save('employee-salary-prediction-report.pdf');
  } catch (error: any) {
    throw new Error(`Unable to generate report: ${error.message || error}. Please try again.`);
  }
}
