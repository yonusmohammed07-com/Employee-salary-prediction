import { CleanEmployeeRecord } from '../types';

export interface DepartmentStat {
  department: string;
  count: number;
  avgSalary: number;
  medianSalary: number;
  minSalary: number;
  maxSalary: number;
}

export interface JobRoleStat {
  jobRole: string;
  department: string;
  count: number;
  avgSalary: number;
  medianSalary: number;
  minSalary: number;
  maxSalary: number;
}

export interface ExperienceGroupStat {
  group: string;
  count: number;
  avgSalary: number;
  minSalary: number;
  maxSalary: number;
}

export interface EducationStat {
  educationLevel: string;
  count: number;
  avgSalary: number;
  medianSalary: number;
  minSalary: number;
  maxSalary: number;
}

export interface PerformanceGroupStat {
  range: string;
  count: number;
  avgSalary: number;
}

export interface SalaryDistributionBucket {
  range: string;
  count: number;
  min: number;
  max: number;
}

export interface OverallDatasetStats {
  totalEmployees: number;
  averageSalary: number;
  medianSalary: number;
  minSalary: number;
  maxSalary: number;
  averageExperience: number;
  averagePerformanceScore: number;
  highestPayingDepartment: { name: string; avgSalary: number };
  highestPayingJobRole: { name: string; avgSalary: number };
  mostCommonEducation: string;
}

export function calculateMedian(numbers: number[]): number {
  if (numbers.length === 0) return 0;
  const sorted = [...numbers].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  if (sorted.length % 2 === 0) {
    return Math.round((sorted[mid - 1] + sorted[mid]) / 2);
  }
  return sorted[mid];
}

export function computeOverallStats(records: CleanEmployeeRecord[]): OverallDatasetStats {
  if (records.length === 0) {
    return {
      totalEmployees: 0,
      averageSalary: 0,
      medianSalary: 0,
      minSalary: 0,
      maxSalary: 0,
      averageExperience: 0,
      averagePerformanceScore: 0,
      highestPayingDepartment: { name: 'N/A', avgSalary: 0 },
      highestPayingJobRole: { name: 'N/A', avgSalary: 0 },
      mostCommonEducation: 'N/A'
    };
  }

  const salaries = records.map((r) => r.salary);
  const totalEmployees = records.length;
  const sumSalary = salaries.reduce((a, b) => a + b, 0);
  const averageSalary = Math.round(sumSalary / totalEmployees);
  const medianSalary = calculateMedian(salaries);
  const minSalary = Math.min(...salaries);
  const maxSalary = Math.max(...salaries);

  const avgExp =
    Math.round(
      (records.reduce((acc, r) => acc + r.years_experience, 0) / totalEmployees) * 10
    ) / 10;

  const avgPerf =
    Math.round(
      (records.reduce((acc, r) => acc + r.performance_score, 0) / totalEmployees) * 10
    ) / 10;

  // Department averages
  const deptMap: Record<string, number[]> = {};
  records.forEach((r) => {
    deptMap[r.department] = deptMap[r.department] || [];
    deptMap[r.department].push(r.salary);
  });

  let highestDept = { name: 'N/A', avgSalary: 0 };
  Object.entries(deptMap).forEach(([dept, sals]) => {
    const avg = sals.reduce((a, b) => a + b, 0) / sals.length;
    if (avg > highestDept.avgSalary) {
      highestDept = { name: dept, avgSalary: Math.round(avg) };
    }
  });

  // Role averages
  const roleMap: Record<string, number[]> = {};
  records.forEach((r) => {
    roleMap[r.job_role] = roleMap[r.job_role] || [];
    roleMap[r.job_role].push(r.salary);
  });

  let highestRole = { name: 'N/A', avgSalary: 0 };
  Object.entries(roleMap).forEach(([role, sals]) => {
    const avg = sals.reduce((a, b) => a + b, 0) / sals.length;
    if (avg > highestRole.avgSalary) {
      highestRole = { name: role, avgSalary: Math.round(avg) };
    }
  });

  // Most common education
  const eduCounts: Record<string, number> = {};
  records.forEach((r) => {
    eduCounts[r.education_level] = (eduCounts[r.education_level] || 0) + 1;
  });
  const mostCommonEducation =
    Object.entries(eduCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "Bachelor's";

  return {
    totalEmployees,
    averageSalary,
    medianSalary,
    minSalary,
    maxSalary,
    averageExperience: avgExp,
    averagePerformanceScore: avgPerf,
    highestPayingDepartment: highestDept,
    highestPayingJobRole: highestRole,
    mostCommonEducation
  };
}

export function computeDepartmentStats(records: CleanEmployeeRecord[]): DepartmentStat[] {
  const map: Record<string, number[]> = {};
  records.forEach((r) => {
    map[r.department] = map[r.department] || [];
    map[r.department].push(r.salary);
  });

  return Object.entries(map)
    .map(([department, sals]) => {
      const count = sals.length;
      const sum = sals.reduce((a, b) => a + b, 0);
      return {
        department,
        count,
        avgSalary: Math.round(sum / count),
        medianSalary: calculateMedian(sals),
        minSalary: Math.min(...sals),
        maxSalary: Math.max(...sals)
      };
    })
    .sort((a, b) => b.avgSalary - a.avgSalary);
}

export function computeJobRoleStats(records: CleanEmployeeRecord[]): JobRoleStat[] {
  const map: Record<string, { sals: number[]; department: string }> = {};
  records.forEach((r) => {
    if (!map[r.job_role]) {
      map[r.job_role] = { sals: [], department: r.department };
    }
    map[r.job_role].sals.push(r.salary);
  });

  return Object.entries(map)
    .map(([jobRole, data]) => {
      const count = data.sals.length;
      const sum = data.sals.reduce((a, b) => a + b, 0);
      return {
        jobRole,
        department: data.department,
        count,
        avgSalary: Math.round(sum / count),
        medianSalary: calculateMedian(data.sals),
        minSalary: Math.min(...data.sals),
        maxSalary: Math.max(...data.sals)
      };
    })
    .sort((a, b) => b.avgSalary - a.avgSalary);
}

export function computeExperienceGroupStats(records: CleanEmployeeRecord[]): ExperienceGroupStat[] {
  const order = ['0–2 years', '3–5 years', '6–10 years', '11–15 years', '16+ years'];
  const map: Record<string, number[]> = {
    '0–2 years': [],
    '3–5 years': [],
    '6–10 years': [],
    '11–15 years': [],
    '16+ years': []
  };

  records.forEach((r) => {
    if (map[r.experience_group]) {
      map[r.experience_group].push(r.salary);
    }
  });

  return order.map((grp) => {
    const sals = map[grp] || [];
    const count = sals.length;
    const avg = count > 0 ? Math.round(sals.reduce((a, b) => a + b, 0) / count) : 0;
    return {
      group: grp,
      count,
      avgSalary: avg,
      minSalary: count > 0 ? Math.min(...sals) : 0,
      maxSalary: count > 0 ? Math.max(...sals) : 0
    };
  });
}

export function computeEducationStats(records: CleanEmployeeRecord[]): EducationStat[] {
  const preferredOrder = ['High School', 'Diploma', "Bachelor's", "Master's", 'Doctorate'];
  const map: Record<string, number[]> = {};

  records.forEach((r) => {
    map[r.education_level] = map[r.education_level] || [];
    map[r.education_level].push(r.salary);
  });

  const allLevels = Array.from(new Set([...preferredOrder, ...Object.keys(map)]));

  return allLevels
    .filter((lvl) => map[lvl] && map[lvl].length > 0)
    .map((educationLevel) => {
      const sals = map[educationLevel];
      const count = sals.length;
      const sum = sals.reduce((a, b) => a + b, 0);
      return {
        educationLevel,
        count,
        avgSalary: Math.round(sum / count),
        medianSalary: calculateMedian(sals),
        minSalary: Math.min(...sals),
        maxSalary: Math.max(...sals)
      };
    });
}

export function computePerformanceStats(records: CleanEmployeeRecord[]): PerformanceGroupStat[] {
  const bins = [
    { label: '0–50', min: 0, max: 50 },
    { label: '51–60', min: 51, max: 60 },
    { label: '61–70', min: 61, max: 70 },
    { label: '71–80', min: 71, max: 80 },
    { label: '81–90', min: 81, max: 90 },
    { label: '91–100', min: 91, max: 100 }
  ];

  return bins.map((bin) => {
    const matched = records.filter(
      (r) => r.performance_score >= bin.min && r.performance_score <= bin.max
    );
    const count = matched.length;
    const avg =
      count > 0 ? Math.round(matched.reduce((a, b) => a + b.salary, 0) / count) : 0;
    return {
      range: bin.label,
      count,
      avgSalary: avg
    };
  });
}

export function computeSalaryDistribution(records: CleanEmployeeRecord[]): SalaryDistributionBucket[] {
  if (records.length === 0) return [];
  const salaries = records.map((r) => r.salary);
  const min = Math.min(...salaries);
  const max = Math.max(...salaries);
  const bucketCount = 6;
  const step = Math.ceil((max - min) / bucketCount / 50000) * 50000 || 500000;

  const buckets: SalaryDistributionBucket[] = [];
  for (let i = 0; i < bucketCount; i++) {
    const bMin = min + i * step;
    const bMax = i === bucketCount - 1 ? max : min + (i + 1) * step;
    const matched = salaries.filter((s) => s >= bMin && (i === bucketCount - 1 ? s <= bMax : s < bMax));
    
    // Format range label in Lakhs or standard
    const minLakh = (bMin / 100000).toFixed(1);
    const maxLakh = (bMax / 100000).toFixed(1);
    buckets.push({
      range: `₹${minLakh}L - ₹${maxLakh}L`,
      count: matched.length,
      min: bMin,
      max: bMax
    });
  }

  return buckets;
}

export function computeCompanySizeStats(records: CleanEmployeeRecord[]): { size: string; count: number; avgSalary: number }[] {
  const map: Record<string, number[]> = { Small: [], Medium: [], Large: [] };
  records.forEach((r) => {
    if (map[r.company_size]) {
      map[r.company_size].push(r.salary);
    }
  });

  return ['Small', 'Medium', 'Large'].map((size) => {
    const sals = map[size] || [];
    const count = sals.length;
    const avg = count > 0 ? Math.round(sals.reduce((a, b) => a + b, 0) / count) : 0;
    return { size, count, avgSalary: avg };
  });
}

export function formatCurrency(amount: number): string {
  if (isNaN(amount)) return '₹0';
  return '₹' + Math.round(amount).toLocaleString('en-IN');
}
